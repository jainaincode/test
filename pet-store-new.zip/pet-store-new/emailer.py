import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

SMTP_USER = "clyro.narola@gmail.com"
SMTP_PASSWORD = "bqjn gwbl swfs jmgg"
SMTP_HOST = "smtp.gmail.com"
SMTP_PORT = "587"


def send_email_jency(receiver: str, subject: str, body: str) -> None:
    msg = MIMEMultipart()
    msg["From"] = SMTP_USER
    msg["To"] = receiver
    msg["Subject"] = subject
    msg.attach(MIMEText(body, "plain"))

    with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
        server.starttls()  # 587 requires STARTTLS
        server.login(SMTP_USER, SMTP_PASSWORD)
        server.send_message(msg)


def send_roi_email(
    receiver: str, subject: str, html_body: str, reply_to: str = None
) -> None:
    msg = MIMEMultipart("alternative")
    msg["From"] = SMTP_USER
    msg["To"] = receiver
    msg["Subject"] = subject
    if reply_to:
        msg.add_header("Reply-To", reply_to)
    msg.attach(MIMEText(html_body, "html"))

    with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
        server.starttls()
        server.login(SMTP_USER, SMTP_PASSWORD)
        server.send_message(msg)
