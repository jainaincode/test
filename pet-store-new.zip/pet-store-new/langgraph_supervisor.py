from dotenv import load_dotenv
import os, json, re
from typing import TypedDict, Optional, List, Dict, Any, Literal
from langchain_openai import AzureChatOpenAI, AzureOpenAIEmbeddings
from langchain_core.output_parsers import StrOutputParser, JsonOutputParser
from langchain_core.prompts import (
    ChatPromptTemplate,
    PromptTemplate,
    MessagesPlaceholder,
)
from langchain.memory import ConversationBufferMemory
from langchain_community.chat_message_histories import ChatMessageHistory
from langchain_core.tools import Tool
from langchain_community.utilities import SQLDatabase
from langchain_community.tools import QuerySQLDatabaseTool
from werkzeug.security import generate_password_hash
from pinecone import Pinecone as PineconeClient
from langchain_community.vectorstores import Pinecone
from langgraph.graph import StateGraph, END
from typing import TypedDict, Annotated, List, Literal, Dict, Any
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, SystemMessage
from IPython.display import Image, display
from datetime import datetime
from operator import add

load_dotenv()

# Environment variables
PINECONE_API_KEY = os.getenv("PINECONE_API_KEY")
PINECONE_ENVIRONMENT = os.getenv("PINECONE_ENVIRONMENT")
AZURE_ENDPOINT = os.getenv(
    "AZURE_ENDPOINT", "https://pg-mcbw91ko-eastus2.cognitiveservices.azure.com/"
)
AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")

# Initialize embeddings and Pinecone
openai_embeddings = AzureOpenAIEmbeddings(
    azure_deployment="text-embedding-3-small",
    openai_api_key=AZURE_OPENAI_API_KEY,
    azure_endpoint="https://narola-ai.cognitiveservices.azure.com/",
    openai_api_version="2024-12-01-preview",
)
pinecone_index_name = "testing"
pinecone = PineconeClient(api_key=PINECONE_API_KEY, environment=PINECONE_ENVIRONMENT)
index = pinecone.Index(pinecone_index_name)

# Initialize LLM and parsers
output_parser = StrOutputParser()
llm = AzureChatOpenAI(
    azure_endpoint=AZURE_ENDPOINT,
    api_key=AZURE_OPENAI_API_KEY,
    azure_deployment="gpt-4.1",
    api_version="2025-01-01-preview",
    temperature=0.2,
)

# Initialize memory
message_history = ChatMessageHistory(session_id="pet_smart")
memory = ConversationBufferMemory(memory_key="history", return_messages=True)

# Database connection
MYSQL_HOST = os.getenv("DB_HOST")
MYSQL_USER = os.getenv("DB_USER")
MYSQL_PASSWORD = os.getenv("DB_PASSWORD")
MYSQL_DB = os.getenv("DB_NAME")
db_uri = f"mysql+mysqlconnector://{MYSQL_USER}:{MYSQL_PASSWORD}@{MYSQL_HOST}/{MYSQL_DB}"


# State definition
class SupervisorState(TypedDict):
    messages: Annotated[List[BaseMessage], add]
    user_id: Optional[str]
    pet_profile_needed: bool
    pet_id: Optional[str]
    pet_context: Optional[str]
    collected_fields: Dict[str, Any]
    response: Dict[str, Any]
    intermediate_steps: List[Dict[str, Any]]
    next_agent: str
    last_agent: str  # New field to track the last agent
    task_complete: bool
    current_task: str
    is_logged_in: bool
    is_final_response: bool


# Tool definitions
def write_query(input_data: Any) -> str:
    db = SQLDatabase.from_uri(db_uri)
    insert_prompt = """
    Given an input dictionary, create a syntactically correct {dialect} query to run. Limit to {top_k} results unless specified.
    Tables: 
    1. products: product_id, name, category, brand, description, price, stock_gty, allergy_tags, nutrition_facts, photo_url, rating, is_active, created_date, modified_date, is_delete
    2. pets: pet_id, user_id, name, species, breed, date_of_birth, gender, weight_kg, photo_url, allergies, adoption_date, current_medication, milestones, notes, created_date, modified_date, is_delete
    3. pet_journals: journal_id, pet_id, entry_date, entry_type, details, created_date, modified_date, is_delete
    4. orders: order_id, user_id, order_date, status, total_amount, delivery_address, delivery_date, payment_method, loyalty_points_earned, applied_discount, special_notes, created_date, modified_date, is_delete
    5. order_items: order_item_id, order_id, product_id, pet_id, quantity, unit_price, subtotal, created_date, modified_date, is_delete
    6. users: user_id, name, email, phone, password_hash, preferred_channel, loyalty_status, referral_code, created_date, modified_date, is_delete
    For pet profile or user insertion, use respective tables with valid columns. For product recommendations, query products table, selecting product_id, name, price, photo_url, description (limit 7). Only use provided column names. 
    Output only the runnable SQL query as a plain string, without Markdown, code blocks, or any extra text or symbols.
    Input: {input}
    """
    query_prompt_template = PromptTemplate.from_template(insert_prompt)
    if isinstance(input_data, dict):
        input_data = json.dumps(input_data)
    prompt = query_prompt_template.invoke(
        {
            "dialect": db.dialect,
            "top_k": 7,
            "table_info": db.get_table_info(),
            "input": input_data,
        }
    )
    query = llm.invoke(prompt).content
    query = query.strip().replace("```sql", "").replace("```", "").strip()
    print(f"Generated SQL query: {query}")
    return query


write_query_tool = Tool(
    name="write_query",
    func=write_query,
    description="Creates executable SQL queries for INSERT, UPDATE, or SELECT operations on tables: products, pets, pet_journals, orders, order_items, users.",
)


def execute_query(sql_query: str) -> Any:
    execute_query_tool = QuerySQLDatabaseTool(db=SQLDatabase.from_uri(db_uri))
    result = execute_query_tool.invoke(sql_query)
    print(f"Execute query result: {result}")
    return result


execute_query_tool = Tool(
    name="execute_query",
    func=execute_query,
    description="Executes SQL queries for INSERT, SELECT, and UPDATE operations.",
)


def pet_journal(input_data: str) -> str:
    print(f"pet_journal input: {input_data}")
    prompt_template = PromptTemplate.from_template(
        """
        Summarize the input into a structured pet journal entry in JSON format:
        {
            "pet_id": "<uuid or empty string if not available>",
            "entry_type": "diet|order|chat_advice|care_note|summary",
            "details": "<summary>",
            "entry_date": "<ISO timestamp or blank>"
        }
        Ensure the output is valid JSON with no extra newlines or formatting issues.
        If no pet_id is available, set it to an empty string.
        input = {input}
        """
    )
    prompt = ChatPromptTemplate.from_messages(
        [("system", prompt_template.format(input=input_data)), ("user", input_data)]
    )
    parser = JsonOutputParser()
    chain = prompt | llm | parser
    try:
        result = chain.invoke({"input": input_data})
        user_id_match = re.search(r"user\s+(\w+)", input_data, re.IGNORECASE)
        if user_id_match and not result.get("pet_id"):
            user_id = user_id_match.group(1)
            pet_query = f"SELECT pet_id FROM pets WHERE user_id = '{user_id}' AND is_delete = 0 LIMIT 1"
            pet_data = execute_query_tool.func(pet_query)
            result["pet_id"] = (
                pet_data[0]["pet_id"]
                if pet_data and isinstance(pet_data, list) and len(pet_data) > 0
                else ""
            )
        print(f"pet_journal output: {result}")
        return json.dumps(result)
    except Exception as e:
        print(f"pet_journal error: {e}")
        return json.dumps(
            {
                "pet_id": "",
                "entry_type": "summary",
                "details": f"Error processing journal entry: {str(e)}",
                "entry_date": "",
            }
        )


pet_journal_tool = Tool(
    name="pet_journal",
    func=pet_journal,
    description="Logs summaries, diet, orders, or care notes to pet_journals table.",
)


def hash_password(plain_text_password: str) -> str:
    return generate_password_hash(plain_text_password)


hash_password_tool = Tool(
    name="hash_password",
    func=hash_password,
    description="Securely hashes a password for database storage.",
)


def create_user(user_data: Dict[str, Any]) -> Dict[str, Any]:
    required_fields = [
        "name",
        "email",
        "phone",
        "preferred_channel",
        "loyalty_status",
        "referral_code",
        "password_hash",
    ]
    if isinstance(user_data, str):
        try:
            user_data = json.loads(user_data)
        except json.JSONDecodeError:
            return {"error": "Invalid input format, expected valid JSON string"}
    missing_fields = [field for field in required_fields if field not in user_data]
    if missing_fields:
        return {"error": f"Missing required user fields: {', '.join(missing_fields)}"}
    query = write_query_tool.func(user_data)
    result = execute_query_tool.func(query)
    return {"result": result}


create_user_tool = Tool(
    name="create_user",
    func=create_user,
    description="Creates a new user in the users table.",
)


def create_pet_profile(pet_data: Dict[str, Any]) -> Dict[str, Any]:
    required_fields = [
        "user_id",
        "name",
        "species",
        "breed",
        "date_of_birth",
        "gender",
        "weight_kg",
        "photo_url",
        "allergies",
        "adoption_date",
        "current_medication",
        "milestones",
        "notes",
    ]
    if isinstance(pet_data, str):
        try:
            pet_data = json.loads(pet_data)
        except json.JSONDecodeError:
            return {"error": "Invalid input format, expected valid JSON string"}
    missing_fields = [field for field in required_fields if field not in pet_data]
    if missing_fields:
        return {"error": f"Missing required pet fields: {', '.join(missing_fields)}"}
    query = write_query_tool.func(pet_data)
    result = execute_query_tool.func(query)
    return {"result": result}


create_pet_profile_tool = Tool(
    name="create_pet_profile",
    func=create_pet_profile,
    description="Creates a new pet profile in the pets table.",
)

tools = [
    write_query_tool,
    execute_query_tool,
    pet_journal_tool,
    hash_password_tool,
    create_user_tool,
    create_pet_profile_tool,
]

# System prompt for supervisor
supervisor_prompt = """
You are a supervisor managing a pet store assistant system with the following agents:
1. LoginHandler - Manages user login and registration
2. PetProfileCreator - Handles creation of pet profiles (supports multiple pets) 
3. QueryHandler - Answers general queries and manages product assistance

Input format: "User query | Pet Profile Needed: true/false | user_id: <ID or None>"
Current state:
- User logged in: {is_logged_in}
- Pet profile needed: {pet_profile_needed}
- Task in progress: {current_task}

Decide the next agent to assign based on the user query and state:
- If user is not logged in (user_id: None) and query suggests personalization (e.g., 'add pet', 'recommend'), assign 'LoginHandler'.
- you need to understand previous questions and answers context to make a decision because in pet_profile and user_login there's a series of questions that they need to make so you cannot give query handler in middle
- If user is logged in, and pet_profile_needed is True, assign to 'PetProfileCreator'.
- If user says 'I want to add a new pet', assign 'PetProfileCreator' (even if pets exist, allow multiple).
- For product queries (e.g., 'buy', 'product') or general questions (e.g., "hi", "i want advice"), assign 'QueryHandler'.
- If the query is generic and no specific action is needed, assign 'QueryHandler'.

Respond with ONLY the agent name (LoginHandler/PetProfileCreator/QueryHandler) or 'DONE'.
"""

# System prompt
system_prompt = """
You are a helpful Pet Store AI assistant. Guide users conversationally to create pet profiles, answer pet queries, and suggest products from the database.

In input you will get user_id, pet_id, pet_context so look at that and provide personalized recommendations. If pet context is none then provide general recommendations.

Product Assistance:
   - Works with or without login. If logged in and pet_context is available, use pet details (species, allergies) for personalized recommendations.
   - For product queries, fetch 4-7 products (product_id, name, price, photo_url, description) from products table, avoiding pet allergies if applicable.
   - Format in JSON: "type": "carousel", "products": ["product_id": "", "name": "", "price": "", "photo_url": "", "description": "", ...]
   - If "add to cart": return "type": "review", <"product_id": "<id>", "upsell": "type": "carousel", "products": [...]>, "text": "Product added to cart! Do you want to see similar products?"
   - If no user_id for cart, collect name, email, phone, then return in json "type": "cart", "text": "You will receive a payment link via email. Your total item cost is: <amount>", "name": "", "email": "", "phone": "", "email_text": "Hello\nThis is your cart. Your total payment is...\n<payment link>\nBest regards, Pet Smart"

Rules:
- Return one valid JSON object: "type": "...", "text": "..." or other specified formats.
- No extra characters, newlines, or JSON strings in response field.
- Be concise, polite, conversational.
- Use "we provide" instead of "Pet Smart provides".
- Never mention AI or journal logging unless asked.
- Use SQL tools only for data retrieval.
- For concerns (e.g., anxiety, adoption), ask clarifying questions, suggest products with estimated monthly cost.
- For generic queries (e.g., "hi", "hey"), respond neutrally without referencing past context unless relevant.
- Use pet_context to tailor responses when available.

"""

# pet profile prompt
pet_profile_prompt = """
You are a helpful Pet Store AI assistant. Guide users conversationally to create pet profiles.
Input Formats:

1, "User query | Pet Profile Needed: true/false | user_id: <ID>"
   - If pet_profile_needed=true (no pet profiles), ask if user wants to create a pet profile.
   - If yes, collect fields one at a time: name, species, breed, date_of_birth, gender, weight_kg, photo_url, allergies, adoption_date, current_medication, milestones, notes.
   - Use create_pet_profile_tool after collecting all fields.
   - If pet_profile_needed=false (pet profiles exist), allow adding another pet if user says yes, collecting same fields.
   - Return: "type": "profile_update", "text": "Pet profile created successfully. <follow-up>"
"""


# Node functions
def parse_input(state: SupervisorState) -> SupervisorState:
    messages = state.get("messages", [])
    if not messages or not isinstance(messages[-1], HumanMessage):
        messages.append(HumanMessage(content="No task"))

    input_content = messages[-1].content
    input_parts = input_content.split("|")
    query = input_parts[0].strip() if len(input_parts) > 0 else input_content
    pet_profile_needed = (
        "Pet Profile Needed: true" in input_parts[1].strip()
        if len(input_parts) > 1
        else False
    )
    user_id_str = (
        input_parts[2].strip().split(":")[1].strip() if len(input_parts) > 2 else "None"
    )
    user_id = user_id_str if user_id_str and user_id_str != "None" else None

    is_logged_in = bool(user_id)

    print(
        f"Parsed input: query={query}, pet_profile_needed={pet_profile_needed}, user_id={user_id}, is_logged_in={is_logged_in}"
    )

    return {
        "messages": messages,
        "user_id": user_id,
        "pet_profile_needed": pet_profile_needed,
        "collected_fields": {},
        "response": {},
        "intermediate_steps": [],
        "next_agent": "",
        "task_complete": False,
        "current_task": query,
        "is_logged_in": is_logged_in,
        "is_final_response": False,
    }


def supervisor_agent(state: SupervisorState) -> SupervisorState:
    task = state["current_task"].lower()
    is_logged_in = state["is_logged_in"]
    pet_profile_needed = state["pet_profile_needed"]

    # create prompt
    prompt_template = PromptTemplate.from_template(supervisor_prompt)
    prompt = prompt_template.format(
        is_logged_in=state["is_logged_in"],
        pet_profile_needed=state["pet_profile_needed"],
        current_task=state["current_task"],
    )

    # Invoke the LLM to get the next agent
    response = llm.invoke(prompt).content.strip()

    # Validate the response to ensure it's one of the expected agent names
    valid_agents = ["LoginHandler", "PetProfileCreator", "QueryHandler", "DONE"]
    if response not in valid_agents:
        print(f"Invalid agent selected by LLM: {response}. Defaulting to QueryHandler.")
        response = "QueryHandler"  # Fallback to QueryHandler if invalid response

    print(f"Supervisor selected agent: {response}")

    # Update the state
    return {
        "messages": state["messages"],
        "next_agent": response,
        "last_agent": response,  # Update last_agent
        "is_final_response": response == "DONE",
    }


def handle_login(state: SupervisorState) -> SupervisorState:
    user_input = state["current_task"].lower()
    collected_fields = state.get("collected_fields", {})

    if "no" in user_input and not collected_fields:
        return {
            "messages": state["messages"]
            + [
                AIMessage(
                    content="No problem, we'll provide general assistance. How can we help?"
                )
            ],
            "collected_fields": {},
            "is_final_response": True,
        }

    required_fields = [
        "name",
        "email",
        "phone",
        "preferred_channel",
        "loyalty_status",
        "referral_code",
        "password",
    ]

    # First question
    if not collected_fields:
        return {
            "messages": state["messages"]
            + [
                AIMessage(
                    content="Hi, I see you're not logged in. Would you like to log in for personalized recommendations?"
                )
            ],
            "is_final_response": True,
        }

    # Collect fields sequentially
    next_field = None
    for field in required_fields:
        if field not in collected_fields:
            next_field = field
            break

    if next_field:
        # Update state with the previous input
        if next_field == "name":
            pass  # First input is the query itself
        else:
            previous_field = required_fields[required_fields.index(next_field) - 1]
            collected_fields[previous_field] = user_input

        # Ask for the next field
        return {
            "messages": state["messages"]
            + [AIMessage(content=f"Please provide your {next_field}.")],
            "collected_fields": collected_fields,
            "is_final_response": True,
        }

    # All fields collected, proceed with creation
    collected_fields["password_hash"] = hash_password_tool.func(
        collected_fields.pop("password")
    )
    result = create_user_tool.func(collected_fields)

    if "error" in result:
        return {
            "messages": state["messages"] + [AIMessage(content=result["error"])],
            "collected_fields": {},
            "is_final_response": True,
        }

    query = f"SELECT user_id FROM users WHERE email = '{collected_fields['email']}'"
    user_id_from_db = execute_query_tool.func(query)
    new_user_id = (
        user_id_from_db[0][0] if user_id_from_db and len(user_id_from_db) > 0 else None
    )

    return {
        "messages": state["messages"]
        + [
            AIMessage(
                content="You have been successfully logged in! How can we assist you today?"
            )
        ],
        "user_id": new_user_id,
        "collected_fields": {},
        "pet_profile_needed": False,
        "is_final_response": True,
    }


def handle_pet_profile(state: Dict[str, Any]) -> Dict[str, Any]:
    user_input = state["current_task"]
    messages = state["messages"]
    collected_fields = state.get("collected_fields", {})

    if not collected_fields:
        # Prompt the user for the first piece of information
        first_prompt_text = (
            "Great! Let's create a pet profile. What is your pet's name?"
        )
        return {
            "messages": messages + [AIMessage(content=first_prompt_text)],
            "collected_fields": {
                "status": "collecting_name"
            },  # This is the crucial line
            "is_final_response": False,
        }
    # Use a StrOutputParser to handle both JSON and non-JSON output
    pet_prompt_template = ChatPromptTemplate.from_messages(
        [("system", pet_profile_prompt), ("user", "{query}")]
    )
    str_parser = StrOutputParser()
    chain = pet_prompt_template | llm | str_parser

    llm_response_content = chain.invoke({"query": user_input})
    print("Jency llm response content:", llm_response_content)

    # Attempt to parse the string as JSON
    try:
        response = json.loads(llm_response_content)
        is_json = True
    except json.JSONDecodeError:
        response = {
            "text": llm_response_content,
            "type": "profile_update",
            "is_final": False,
        }
        is_json = False

    # Process LLM response
    text = response.get("text", "Please provide the next detail for your pet.")
    response_type = response.get("type", "profile_update")
    is_final = response.get("is_final", False)
    pet_profile_needed = response.get("pet_profile_needed", state["pet_profile_needed"])

    if is_json and response_type == "profile_update" and is_final:
        # All fields collected, perform data entry
        collected_fields = response.get("collected_fields", {})
        collected_fields["user_id"] = state["user_id"]
        result = create_pet_profile_tool.func(collected_fields)
        if "error" in result:
            return {
                "messages": messages
                + [
                    AIMessage(
                        content=json.dumps(
                            {
                                "type": "profile_update",
                                "text": f"Error: {result['error']}. Please try again.",
                            }
                        )
                    )
                ],
                "is_final_response": True,
                "pet_profile_needed": False,
            }
        return {
            "messages": messages
            + [
                AIMessage(
                    content=json.dumps(
                        {
                            "type": "profile_update",
                            "text": response.get(
                                "text", "Profile created! Want to add another pet?"
                            ),
                        }
                    )
                )
            ],
            "is_final_response": True,
            "pet_profile_needed": False,
        }

    # Return LLM response for field collection
    return {
        "messages": messages
        + [
            AIMessage(content=text)
        ],  # The response is a plain string, so don't re-encode it as JSON
        "is_final_response": True,
        "pet_profile_needed": pet_profile_needed,
        "collected_fields": collected_fields,
    }


def handle_query(state: SupervisorState) -> SupervisorState:
    query = state["current_task"].lower()
    user_id = state["user_id"]
    pet_id = state.get("pet_id")
    pet_context = state.get("pet_context", "No pet data available.")
    pet_profile_needed = state["pet_profile_needed"]
    collected_fields = state.get("collected_fields", {})
    messages = state["messages"]

    # create chain
    system_prompt_template = ChatPromptTemplate.from_messages(
        [("system", system_prompt), ("user", "{query}")]
    )

    parser = JsonOutputParser()
    chain = system_prompt_template | llm | parser

    # Fetch pet data if user_id and pet_id are available
    input_data = {
        "query": f"{query} | Pet Profile Needed: {pet_profile_needed} | user_id: {user_id or 'None'} | pet_id: {pet_id or 'None'} | pet_context: {pet_context or 'None'}",
    }
    try:
        response = chain.invoke(input_data)
        print(f"LLM response: {response}")

        if not isinstance(response, dict) or "type" not in response:
            raise ValueError("LLM did not return a valid JSON object with 'type' field")

        if response["type"] == "carousel":
            product_query_dict = {
                "query": query,
                "table": "products",
                "fields": ["product_id", "name", "price", "photo_url", "description"],
                "limit": 7,
            }

            if user_id and pet_id and pet_context != "No pet data available.":
                # Parse pet_context to extract species and allergies
                species = re.search(r"Species: (\w+)", pet_context)
                allergies = re.search(r"Allergies: ([\w\s,]+|none)", pet_context)
                if species:
                    product_query_dict["query"] = (
                        f"products for {species.group(1)} avoiding {allergies.group(1) if allergies else 'none'}"
                    )

            sql_query = write_query_tool.func(product_query_dict)
            result = execute_query_tool.func(sql_query)

            products = []
            if result and len(result) > 0:
                products = [
                    {
                        "product_id": row[0],
                        "name": row[1],
                        "price": float(row[2]),
                        "photo_url": row[3],
                        "description": row[4],
                    }
                    for row in result
                ]

            response = {
                "type": "carousel",
                "products": products if products else [],
                "text": (
                    response.get(
                        "text",
                        (
                            f"Here are some products for your pet."
                            if pet_context != "No pet data available."
                            else "Here are some products we found."
                        ),
                    )
                    if products
                    else "Sorry, no products were found that match your request."
                ),
            }

        elif response["type"] == "cart" and not user_id:
            required_fields = ["name", "email", "phone"]
            next_field = None
            for field in required_fields:
                if field not in collected_fields:
                    next_field = field
                    break

            if next_field:
                if collected_fields and query != state["current_task"]:
                    prev_field = required_fields[required_fields.index(next_field) - 1]
                    collected_fields[prev_field] = query

                questions = {
                    "name": "Please provide your name.",
                    "email": "Please provide your email.",
                    "phone": "Please provide your phone number.",
                }
                return {
                    "messages": messages + [AIMessage(content=questions[next_field])],
                    "collected_fields": collected_fields,
                    "is_final_response": False,
                    "pet_context": pet_context,
                }

            response = {
                "type": "cart",
                "text": f"You will receive a payment link via email. Your total item cost is: {response.get('amount', 'N/A')}",
                "name": collected_fields["name"],
                "email": collected_fields["email"],
                "phone": collected_fields["phone"],
                "email_text": f"Hello\nThis is your cart. Your total payment is {response.get('amount', 'N/A')}.\n<payment link>\nBest regards, Pet Smart",
            }
            collected_fields = {}

        elif response["type"] == "profile_update" and pet_profile_needed:
            return {
                "messages": messages
                + [
                    AIMessage(
                        content=response.get(
                            "text", "Would you like to create a pet profile now?"
                        )
                    )
                ],
                "next_agent": "PetProfileCreator",
                "last_agent": "QueryHandler",
                "is_final_response": False,
                "pet_context": pet_context,
            }

        return {
            "messages": messages + [AIMessage(content=json.dumps(response))],
            "collected_fields": collected_fields,
            "is_final_response": True,
            "pet_context": pet_context,
        }

    except Exception as e:
        print(f"Error in handle_query: {e}")
        return {
            "messages": messages
            + [
                AIMessage(
                    content=json.dumps(
                        {
                            "type": "text",
                            "text": (
                                f"Sorry, something went wrong. How can we assist you with your pet?"
                                if pet_context != "No pet data available."
                                else "Sorry, something went wrong. How can we assist you?"
                            ),
                        }
                    )
                )
            ],
            "is_final_response": True,
            "pet_context": pet_context,
        }


def router(
    state: SupervisorState,
) -> Literal[
    "supervisor", "LoginHandler", "PetProfileCreator", "QueryHandler", "__end__"
]:
    # End the graph if a final response is ready
    if state.get("is_final_response", False):
        return END

    # If collected_fields exist, continue the task with the last agent
    # The last_agent field tells the router where to go next to continue the multi-turn conversation.
    if state.get("collected_fields"):
        last_agent = state.get("last_agent")
        if last_agent:
            return last_agent

    # Fallback to the supervisor for initial routing
    next_agent = state.get("next_agent", "supervisor")
    if next_agent == "LoginHandler":
        return "LoginHandler"
    elif next_agent == "PetProfileCreator":
        return "PetProfileCreator"
    elif next_agent == "QueryHandler":
        return "QueryHandler"

    return "supervisor"


# Build the graph
workflow = StateGraph(SupervisorState)
workflow.add_node("parse_input", parse_input)
workflow.add_node("supervisor", supervisor_agent)
workflow.add_node("LoginHandler", handle_login)
workflow.add_node("PetProfileCreator", handle_pet_profile)
workflow.add_node("QueryHandler", handle_query)
workflow.set_entry_point("parse_input")

# Initial flow: parse input -> supervisor -> router
workflow.add_edge("parse_input", "supervisor")
workflow.add_conditional_edges(
    "supervisor",
    router,
    {
        "LoginHandler": "LoginHandler",
        "PetProfileCreator": "PetProfileCreator",
        "QueryHandler": "QueryHandler",
        "DONE": END,
    },
)

# Individual agent flows. They now all loop back to themselves until the task is complete.
workflow.add_conditional_edges(
    "LoginHandler",
    router,
    {
        "LoginHandler": "LoginHandler",
        END: END,
    },
)
workflow.add_conditional_edges(
    "PetProfileCreator",
    router,
    {
        "PetProfileCreator": "PetProfileCreator",
        END: END,
    },
)
workflow.add_conditional_edges(
    "QueryHandler",
    router,
    {
        "QueryHandler": "QueryHandler",
        END: END,
    },
)

# Compile the graph
app = workflow.compile()
"""try:
    png_data = app.get_graph().draw_mermaid_png()
    with open("mermaid_graph3.png", "wb") as f:
        f.write(png_data)
    display(Image("mermaid_graph3.png"))
except Exception:
    pass

"""


def create_pet_agent3():
    return app
