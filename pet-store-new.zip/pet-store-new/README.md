The main file for fastapi code is main2.py.
After installing requirements.txt. We need to run wsgi.py with : python3 wsgi.py command.