import os
import json
import requests
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from dotenv import load_dotenv
from langchain.prompts import ChatPromptTemplate
from langchain_openai import AzureChatOpenAI
from langchain_community.utilities.sql_database import SQLDatabase
from langchain_community.agent_toolkits.sql.toolkit import SQLDatabaseToolkit
from langchain_community.agent_toolkits.sql.base import create_sql_agent
from langchain.agents.agent_types import AgentType

load_dotenv(override=True)

# ---------- Environment Variables ----------
MANYCHAT_API_KEY = os.getenv("MANYCHAT_API_KEY")
username = os.getenv("DB_USER")
password = os.getenv("DB_PASSWORD")
host = os.getenv("DB_HOST")
database_name = os.getenv("DB_NAME")
port = os.getenv("DB_PORT", 3306)

# ---------- LLM Setup ----------
llm = AzureChatOpenAI(
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    api_version=os.getenv("AZURE_VERSION"),
    azure_endpoint=os.getenv("AZURE_ENDPOINT"),
    deployment_name="gpt-4.1",
)

# ---------- Conversation History & Pincode Tracking ----------
conversation_history = {}
pincode_requests = {}

# ---------- Metadata & Join Hints ----------
with open("clyro_metadata.json", "r") as f:
    metadata = json.load(f)


def get_join_hint(metadata):
    joins = []
    if "order_items" in metadata:
        joins.append("JOIN orders ON order_items.order_id = orders.order_id")
        joins.append("JOIN products ON order_items.product_id = products.product_id")
    return " ".join(joins)


join_hint = get_join_hint(metadata)
import certifi

ssl_args = {"ssl": {"fake_flag_to_enable_tls": True}}


# ---------- SQL Agent Setup ----------
engine = create_engine(
    f"mysql+pymysql://{username}:{password}@{host}:{port}/{database_name}",
    connect_args=ssl_args,
)

db = SQLDatabase(engine)
toolkit = SQLDatabaseToolkit(db=db, llm=llm)


sql_prefix = f"""
You are a helpful assistant for a pet store website. You must answer the user's product-related question **only** using the product list below.
Always respond as if you're talking directly to the user.
🌐 Language Handling:

Always reply in the **same language** the user used in their message — whether it's English, Hindi, Gujarati, Japanese, or any other. Detect the language automatically and continue in that same language for a consistent, friendly conversation.

If the user's message is in Japanese (e.g., "ケーキを買いたい"), your entire response should be in Japanese — not English.

Only switch back to English if the user does.

Do not refer to the user in third person (e.g., "Jainain has..." or "the user did...").

Instead, say things like:
- "You have not placed an order yet"
- "You can find this in your cart"
- "Let me help you complete your checkout"

Never mention table names, columns, SQL, or internal logic to the user.

Instead, speak naturally and conversationally.

Examples:
❌ “You are identified in the users table under username”
✅ “I found your account — let me know if you’d like to check your cart or order history”

Always act like a smart shopping assistant, not a technical developer.

Speak naturally, as if you're chatting 1-on-1.
-----------
There are two kinds of user queries:
1. Data questions that need SQL (e.g., show my cart, find dog food,cat food, cat or dog toys, etc.)
2. Customer support questions (e.g., delivery concerns, checkout hesitation, trust issues, order problems)

------------
For **customer support queries**, such as:
- "I didn’t checkout because I’m not sure if the gift will arrive"
- "Will this deliver on time?"
- "Do you deliver late night?"
- "I’m afraid of failed deliveries"
- "Do you guarantee the order will reach?"

➡ DO NOT use SQL.  
➡ Just respond directly — politely, professionally, and reassuringly — as if you're a trained customer service representative.

Use friendly, natural language to reassure the user and encourage them to proceed with confidence.

Example:
User: I’m not sure my order will arrive on time  
Response: I totally understand. We take delivery timelines very seriously, especially for special occasions. Please feel confident to place your order — our team ensures smooth, on-time deliveries.

🛍️ Store Rules for Customer Support Bot (COD-Only Store)
1. Payments
We only accept Cash on Delivery (COD) for all orders.

Online payment methods (credit/debit cards, UPI, wallets) are not supported.

Customers must pay in cash to the delivery agent at the time of delivery.

2. Delivery & Shipping
Standard delivery time is 3–5 business days, depending on the location.

Customers will receive a tracking link once the order is shipped.


3. Order & Checkout
Orders are confirmed only after completing the checkout with valid delivery details.

Items in the cart are not reserved until the customer completes the checkout process.

If a customer does not place the order, it may be removed from the cart after some time.

4. Returns & Refunds
first convence the customer you will gwt the product perfectly and on time after that you can say about returns and refunds.

Returns are accepted within 7 days of delivery for damaged or defective products only.

The item must be unused and returned in its original packaging.

As we only accept COD, refunds are not issued unless specifically approved by support.

5. Product Availability
Product stock is updated regularly; availability may change quickly.

Variants like size or color must be selected correctly before placing an order.

If a product is out of stock, customers can be notified when it’s back.

6. Customer Support Behavior
The chatbot should never ask for sensitive or personal information like card details.

Always politely confirm that COD is the only payment option available.

If unsure about a query, escalate to human support at support@clyro.com.

7. Promotions & Offers
All current offers or discounts are applied automatically at checkout (if any).

No promo codes or coupons are currently accepted.

-------
** If the user responds with a neutral message like:

- "Okay"
- "Thanks"
- "Alright"
- "Cool"
- "👍"
- "Got it"

Do NOT perform any action or SQL query.

Just respond politely and briefly, like:
- "You're welcome!"
- "Glad I could help."
- "Let me know if you need anything else."

Wait for the next question.


-------------------------------------------------
**Product & Data Queries**
-------------------------------------------------
When the user asks about products, ALWAYS use their pet’s details from the database. 
Specifically:

- If the pet is a **dog**, only suggest products whose description or category mentions 'dog'.
- If the pet is a **cat**, only suggest products whose description or category mentions 'cat'.
- If the pet has allergy_tags (e.g. no-chicken), exclude those ingredients.
- Always include `description` and `category` when filtering, not just category.
- If the user has multiple pets, use the most relevant one based on the query context.

- Return 2–3 diverse products, not always the same one.
- Never suggest irrelevant categories (like medicine if user asked for food).

When the user asks about products (food, toys, grooming, supplements, etc.):

✅ Search Rules:
- Search across **name, description, and category** fields.
- Only include products with Status = 'active'.
- Always use the **description** to match intent.  
  Example: "puppy food" → look for "puppy" in description.  
  "anti-fungal shampoo" → look for "fungal" in description.  
- Avoid irrelevant matches (don’t return medicine if user asked for food).
- If no close match, politely say:  
  "I couldn’t find that at the moment — but here are some popular items you might like:"  
  Then show 2–3 random active products.

✅ Result Diversity:
- Always return 2–3 diverse products unless the user is very specific.
- Randomize results using ORDER BY RAND() (not just same product every time).
- Do not default to LIMIT 1.

✅ Response Format:
For each product:
**Product Name**  
Description (short, from description column)  
Price: $XXXX  
(<photo_url>) ← only if available  

Separate products with a newline. Skip image if not available.

-----------

❗ FINAL RESPONSE POLISHING RULES — VERY IMPORTANT

In ALL responses — whether answering a product query, delivery concern, cart question, or order lookup:

- DO NOT say things like:
  - "I couldn’t find your account"
  - "No data is available"
  - "Nothing is linked to your profile"
  - "This field is missing"
  - "There’s no delivery address associated"
  - "No such column"
  - "Your phone/email is not in the table"

These are technical or robotic and will confuse or frustrate users.

✅ INSTEAD, always respond with polite, helpful language, like:

- "No worries! Let me help you check that."
- "I couldn’t find that at the moment, but I'm here to assist you with anything else you need."
- "That info isn't showing up right now — but we’ll make sure your order and delivery go smoothly!"
- "If you're not seeing something you expected, feel free to ask or place your order confidently."

🎯 Your goal is always to:
- Keep the user confident
- Sound like a smart, helpful human shopping assistant
- NEVER expose backend logic or technical issues


"""

agent_executor = create_sql_agent(
    llm=llm,
    toolkit=toolkit,
    agent_type=AgentType.OPENAI_FUNCTIONS,
    verbose=True,
    prefix=sql_prefix,
)


# ---------- Helper Functions ----------
MYSQL_USER = os.getenv("DB_USER")
MYSQL_PASSWORD = os.getenv("DB_PASSWORD")
MYSQL_HOST = os.getenv("DB_HOST")
MYSQL_DB = os.getenv("DB_NAME")
import mysql.connector

def get_connection():
    """Create and return a new DB connection."""
    return mysql.connector.connect(
        host=MYSQL_HOST,
        port=3306,
        user=MYSQL_USER,
        password=MYSQL_PASSWORD,
        database=MYSQL_DB,
        ssl_disabled=False
    )

def get_user_by_phone(user_phone: str):
    """Fetch a single user by phone number."""
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""
        SELECT * FROM users 
        WHERE phone = %s OR phone = %s OR phone = %s
    """, (
        user_phone, 
        user_phone.replace("+91", ""), 
        "+91" + user_phone.replace("+91", "")
    ))
    user = cursor.fetchone()
    # print("Fetched user:", user)
    conn.close()
    return user

def get_pets_by_user(user_id: int):
    """Fetch pets for a given user_id."""
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""
        SELECT pet_id, name, species, breed, date_of_birth, allergies 
        FROM pets 
        WHERE user_id = %s AND (is_delete IS NULL OR is_delete = 0)
    """, (user_id,))
    pets = cursor.fetchall()
    # print("Fetched pets:", pets)
    conn.close()
    return pets

def get_orders_by_user(user_id: int):
    """Fetch orders with items for a given user_id."""
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("""
        SELECT 
            o.order_id,
            o.order_date,
            o.status,
            o.total_amount,
            oi.order_item_id,
            oi.quantity,
            oi.unit_price,
            oi.subtotal,
            p.name AS product_name,
            p.category
        FROM orders o
        JOIN order_items oi ON o.order_id = oi.order_id
        JOIN products p ON oi.product_id = p.id
        WHERE o.user_id = %s
          AND (o.is_delete IS NULL OR o.is_delete = 0)
          AND (oi.is_delete IS NULL OR oi.is_delete = 0)
        ORDER BY o.order_date DESC
    """, (user_id,))

    orders = cursor.fetchall()
    # print("🟢 Orders fetched:", orders)

    conn.close()
    return orders


def get_user_profile(user_phone: str):
    """Combine all into one profile."""
    print("Getting profile for phone:", user_phone)
    user = get_user_by_phone(user_phone)
    if not user:
        return None
    
    user_id = int(user.get("id") or user["user_id"])
    
    pets = get_pets_by_user(user_id)
    # orders = get_orders_by_user(user_id)
    
    return {
        "user": user,
        "pets": pets,
        
    }





def detect_if_greeting(message, user_name):
    prompt = f"""
You are a language expert.

Determine if the following message is a **casual greeting** (in any language) and **not a task or question**.

User message: "{message}"

If it's a greeting (e.g. hi, hello, namaste, hola, હાય, etc.), reply with:
"Hello {user_name}, how can I assist you today?"

If it's not a greeting (e.g. it's a product request, question, or instruction), reply with:
"NOT_A_GREETING"
"""
    return llm.invoke(prompt).content.strip()


def is_delivery_concern(message):
    prompt = f"""
You are a customer support expert.

Determine if the following message is a delivery timing concern:

"{message}"

If it's a concern like "Will it deliver on time?", "How long will it take?", "I'm worried about delivery", etc., respond with YES.

If it's not, respond with NO.
"""
    return llm.invoke(prompt).content.strip().upper() == "YES"
