from dotenv import load_dotenv
import os, json, re
from typing import TypedDict, Optional, List, Dict, Any
from langchain_openai import AzureChatOpenAI, AzureOpenAIEmbeddings
from langchain_core.output_parsers import StrOutputParser, JsonOutputParser
from langchain_core.prompts import (
    ChatPromptTemplate,
    PromptTemplate,
    MessagesPlaceholder,
)
from langchain.memory import ConversationBufferMemory
from langchain_community.chat_message_histories import ChatMessageHistory
from langchain_core.tools import Tool
from langchain_community.utilities import SQLDatabase
from langchain_community.tools import QuerySQLDatabaseTool
from werkzeug.security import generate_password_hash
from pinecone import Pinecone as PineconeClient
from langchain_community.vectorstores import Pinecone
from langgraph.graph import StateGraph, END
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage
from IPython.display import Image, display

load_dotenv()

# Environment variables
PINECONE_API_KEY = os.getenv("PINECONE_API_KEY")
PINECONE_ENVIRONMENT = os.getenv("PINECONE_ENVIRONMENT")
AZURE_ENDPOINT = os.getenv(
    "AZURE_ENDPOINT", "https://pg-mcbw91ko-eastus2.cognitiveservices.azure.com/"
)
AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")

# Initialize embeddings and Pinecone
openai_embeddings = AzureOpenAIEmbeddings(
    azure_deployment="text-embedding-3-small",
    openai_api_key=AZURE_OPENAI_API_KEY,
    azure_endpoint="https://narola-ai.cognitiveservices.azure.com/",
    openai_api_version="2024-12-01-preview",
)
pinecone_index_name = "testing"
pinecone = PineconeClient(api_key=PINECONE_API_KEY, environment=PINECONE_ENVIRONMENT)
index = pinecone.Index(pinecone_index_name)

# Initialize LLM and parsers
output_parser = StrOutputParser()
llm = AzureChatOpenAI(
    azure_endpoint=AZURE_ENDPOINT,
    api_key=AZURE_OPENAI_API_KEY,
    azure_deployment="gpt-4.1",
    api_version="2025-01-01-preview",
    temperature=0.2,
)

# Initialize memory
message_history = ChatMessageHistory(session_id="pet_smart")
memory = ConversationBufferMemory(memory_key="history", return_messages=True)

# Database connection
MYSQL_HOST = os.getenv("DB_HOST")
MYSQL_USER = os.getenv("DB_USER")
MYSQL_PASSWORD = os.getenv("DB_PASSWORD")
MYSQL_DB = os.getenv("DB_NAME")
db_uri = f"mysql+mysqlconnector://{MYSQL_USER}:{MYSQL_PASSWORD}@{MYSQL_HOST}/{MYSQL_DB}"


# State definition
class AgentState(TypedDict):
    input: str
    user_id: Optional[str]
    pet_profile_needed: bool
    history: List[Dict[str, Any]]
    collected_fields: Dict[str, Any]
    response: Dict[str, Any]
    intermediate_steps: List[Dict[str, Any]]


# Tool definitions
def write_query(input_data: Any) -> str:
    db = SQLDatabase.from_uri(db_uri)
    insert_prompt = """
    Given an input dictionary, create a syntactically correct {dialect} query to run. Limit to {top_k} results unless specified.
    Tables: 
    1. products: product_id, name, category, brand, description, price, stock_gty, allergy_tags, nutrition_facts, photo_url, rating, is_active, created_date, modified_date, is_delete
    2. pets: pet_id, user_id, name, species, breed, date_of_birth, gender, weight_kg, photo_url, allergies, adoption_date, current_medication, milestones, notes, created_date, modified_date, is_delete
    3. pet_journals: journal_id, pet_id, entry_date, entry_type, details, created_date, modified_date, is_delete
    4. orders: order_id, user_id, order_date, status, total_amount, delivery_address, delivery_date, payment_method, loyalty_points_earned, applied_discount, special_notes, created_date, modified_date, is_delete
    5. order_items: order_item_id, order_id, product_id, pet_id, quantity, unit_price, subtotal, created_date, modified_date, is_delete
    6. users: user_id, name, email, phone, password_hash, preferred_channel, loyalty_status, referral_code, created_date, modified_date, is_delete
    For pet profile or user insertion, use respective tables with valid columns. For product recommendations, query products table, selecting product_id, name, price, photo_url, description (limit 7). Only use provided column names. 
    Output only the runnable SQL query as a plain string, without Markdown, code blocks, or any extra text or symbols.
    Input: {input}
    """
    query_prompt_template = PromptTemplate.from_template(insert_prompt)
    if isinstance(input_data, dict):
        input_data = json.dumps(input_data)
    prompt = query_prompt_template.invoke(
        {
            "dialect": db.dialect,
            "top_k": 7,
            "table_info": db.get_table_info(),
            "input": input_data,
        }
    )
    query = llm.invoke(prompt).content
    query = query.strip().replace("```sql", "").replace("```", "").strip()
    print(f"Generated SQL query: {query}")
    return query


write_query_tool = Tool(
    name="write_query",
    func=write_query,
    description="Creates executable SQL queries for INSERT, UPDATE, or SELECT operations on tables: products, pets, pet_journals, orders, order_items, users.",
)


def execute_query(sql_query: str) -> Any:
    execute_query_tool = QuerySQLDatabaseTool(db=SQLDatabase.from_uri(db_uri))
    result = execute_query_tool.invoke(sql_query)
    print(f"Execute query result: {result}")
    return result


execute_query_tool = Tool(
    name="execute_query",
    func=execute_query,
    description="Executes SQL queries for INSERT, SELECT, and UPDATE operations.",
)


def pet_journal(input_data: str) -> str:
    print(f"pet_journal input: {input_data}")
    prompt_template = PromptTemplate.from_template(
        """
        Summarize the input into a structured pet journal entry in JSON format:
        {
            "pet_id": "<uuid or empty string if not available>",
            "entry_type": "diet|order|chat_advice|care_note|summary",
            "details": "<summary>",
            "entry_date": "<ISO timestamp or blank>"
        }
        Ensure the output is valid JSON with no extra newlines or formatting issues.
        If no pet_id is available, set it to an empty string.
        input = {input}
        """
    )
    prompt = ChatPromptTemplate.from_messages(
        [("system", prompt_template.format(input=input_data)), ("user", input_data)]
    )
    parser = JsonOutputParser()
    chain = prompt | llm | parser
    try:
        result = chain.invoke({"input": input_data})
        user_id_match = re.search(r"user\s+(\w+)", input_data, re.IGNORECASE)
        if user_id_match and not result.get("pet_id"):
            user_id = user_id_match.group(1)
            pet_query = f"SELECT pet_id FROM pets WHERE user_id = '{user_id}' AND is_delete = 0 LIMIT 1"
            pet_data = execute_query_tool.func(pet_query)
            result["pet_id"] = (
                pet_data[0]["pet_id"]
                if pet_data and isinstance(pet_data, list) and len(pet_data) > 0
                else ""
            )
        print(f"pet_journal output: {result}")
        return json.dumps(result)
    except Exception as e:
        print(f"pet_journal error: {e}")
        return json.dumps(
            {
                "pet_id": "",
                "entry_type": "summary",
                "details": f"Error processing journal entry: {str(e)}",
                "entry_date": "",
            }
        )


pet_journal_tool = Tool(
    name="pet_journal",
    func=pet_journal,
    description="Logs summaries, diet, orders, or care notes to pet_journals table.",
)


def hash_password(plain_text_password: str) -> str:
    return generate_password_hash(plain_text_password)


hash_password_tool = Tool(
    name="hash_password",
    func=hash_password,
    description="Securely hashes a password for database storage.",
)


def create_user(user_data: Dict[str, Any]) -> Dict[str, Any]:
    required_fields = [
        "name",
        "email",
        "phone",
        "preferred_channel",
        "loyalty_status",
        "referral_code",
        "password_hash",
    ]
    if isinstance(user_data, str):
        try:
            user_data = json.loads(user_data)
        except json.JSONDecodeError:
            return {"error": "Invalid input format, expected valid JSON string"}
    missing_fields = [field for field in required_fields if field not in user_data]
    if missing_fields:
        return {"error": f"Missing required user fields: {', '.join(missing_fields)}"}
    query = write_query_tool.func(user_data)
    result = execute_query_tool.func(query)
    return {"result": result}


create_user_tool = Tool(
    name="create_user",
    func=create_user,
    description="Creates a new user in the users table.",
)


def create_pet_profile(pet_data: Dict[str, Any]) -> Dict[str, Any]:
    required_fields = [
        "user_id",
        "name",
        "species",
        "breed",
        "date_of_birth",
        "gender",
        "weight_kg",
        "photo_url",
        "allergies",
        "adoption_date",
        "current_medication",
        "milestones",
        "notes",
    ]
    if isinstance(pet_data, str):
        try:
            pet_data = json.loads(pet_data)
        except json.JSONDecodeError:
            return {"error": "Invalid input format, expected valid JSON string"}
    missing_fields = [field for field in required_fields if field not in pet_data]
    if missing_fields:
        return {"error": f"Missing required pet fields: {', '.join(missing_fields)}"}
    query = write_query_tool.func(pet_data)
    result = execute_query_tool.func(query)
    return {"result": result}


create_pet_profile_tool = Tool(
    name="create_pet_profile",
    func=create_pet_profile,
    description="Creates a new pet profile in the pets table.",
)

tools = [
    write_query_tool,
    execute_query_tool,
    pet_journal_tool,
    hash_password_tool,
    create_user_tool,
    create_pet_profile_tool,
]

# System prompt
system_prompt = """
You are a helpful Pet Store AI assistant. Guide users conversationally to create pet profiles, answer pet queries, and suggest products from the database.

Input Formats:
1. Not logged in: "User query | Pet Profile Needed: false | user_id: None"
   - Ask if user wants to login for personalized recommendations if no user_id.
   - If yes, collect one field at a time: name, email, phone, preferred_channel, loyalty_status, referral_code, password.
   - Call hash_password_tool for password, then use create_user_tool.
   - After success, return: "type": "text", "text": "<success message>"
   - If no, provide general answers to queries (product info, etc.).
2. Logged in: "User query | Pet Profile Needed: true/false | user_id: <ID>"
   - If pet_profile_needed=true (no pet profiles), ask if user wants to create a pet profile.
   - If yes, collect fields one at a time: name, species, breed, date_of_birth, gender, weight_kg, photo_url, allergies, adoption_date, current_medication, milestones, notes.
   - Use create_pet_profile_tool after collecting all fields.
   - If pet_profile_needed=false (pet profiles exist), allow adding another pet if user says yes, collecting same fields.
   - Return: "type": "profile_update", "text": "Pet profile created successfully. <follow-up>"

Product Assistance:
- Works with or without login. If logged in, use pet profile (species, allergies) for personalized recommendations.
- For product queries, fetch 4-7 products (product_id, name, price, photo_url, description) from products table, avoiding pet allergies if applicable.
- Format in json: "type": "carousel", "products": ["product_id": "", "name": "", "price": "", "photo_url": "", "description": "", ...]
- If "add to cart": return "type": "review", "product_id": "<id>", "upsell": "type": "carousel", "products": [...]
- Suggest upselling/bundling: "Do you want to see similar products?"
- If no user_id, collect name, email, phone for cart, then return "type": "cart", "text": "You will receive a payment link via email. Your total item cost is: <amount>", "name": "", "email": "", "phone": "", "email_text": "Hello\nThis is your cart. Your total payment is...\n<payment link>\nBest regards, Pet Smart"

Rules:
- Return one valid JSON object: "type": "...", "text": "..." or other specified formats.
- No extra characters, newlines, or JSON strings in response field.
- Be concise, polite, conversational.
- Use "we provide" instead of "Pet Smart provides".
- Never mention AI or journal logging unless asked.
- Use SQL tools only for profile creation/updates or data retrieval.
- For concerns (e.g., anxiety, adoption), ask clarifying questions, suggest products with estimated monthly cost.
- For generic queries (e.g., "hi", "hey"), respond neutrally without referencing past context unless relevant.
- For pet profile creation, collect fields sequentially and store in collected_fields until all are gathered, then call create_pet_profile_tool.
"""


# Node functions
def parse_input(state: AgentState) -> AgentState:
    input_parts = state["input"].split("|")
    query = input_parts[0].strip()
    pet_profile_needed = "Pet Profile Needed: true" in input_parts[1].strip()
    user_id = (
        input_parts[2].strip().split(":")[1].strip() if len(input_parts) > 2 else None
    )
    if user_id == "None":
        user_id = None
    print(
        f"Parsed input: query={query}, pet_profile_needed={pet_profile_needed}, user_id={user_id}"
    )
    return {
        "input": query,
        "user_id": user_id,
        "pet_profile_needed": pet_profile_needed,
        "history": state.get("history", []),
        "collected_fields": state.get("collected_fields", {}),
        "response": state.get("response", {}),
        "intermediate_steps": state.get("intermediate_steps", []),
    }


def handle_login(state: AgentState) -> AgentState:
    if not state["user_id"]:
        required_fields = [
            "name",
            "email",
            "phone",
            "preferred_channel",
            "loyalty_status",
            "referral_code",
            "password",
        ]
        collected_fields = state.get("collected_fields", {})

        if not collected_fields:
            return {
                "response": {
                    "type": "text",
                    "text": "Would you like to log in for personalized recommendations?",
                },
                "collected_fields": collected_fields,
            }

        if state["input"].lower() in ["yes", "create account", "log in"]:
            for field in required_fields:
                if field not in collected_fields:
                    return {
                        "response": {
                            "type": "text",
                            "text": f"Please provide your {field}.",
                        },
                        "collected_fields": collected_fields,
                    }
            password = collected_fields.pop("password")
            hashed_password = hash_password_tool.func(password)
            collected_fields["password_hash"] = hashed_password
            result = create_user_tool.func(collected_fields)
            if "error" in result:
                return {
                    "response": {"type": "text", "text": result["error"]},
                    "collected_fields": collected_fields,
                }
            query = (
                f"SELECT user_id FROM users WHERE email = '{collected_fields['email']}'"
            )
            user_id = execute_query_tool.func(query)
            if user_id and isinstance(user_id, list) and len(user_id) > 0:
                user_id = user_id[0]["user_id"]
            state["user_id"] = user_id
            return {
                "response": {
                    "type": "text",
                    "text": "User created successfully. How can we assist you further?",
                },
                "collected_fields": {},
                "pet_profile_needed": False,  # Reset after login
            }

        return {
            "response": {
                "type": "text",
                "text": "Alright, we’ll provide general answers. How can we assist you?",
            },
            "collected_fields": {},
        }

    return state


def handle_pet_profile(state: AgentState) -> AgentState:
    if state["user_id"]:
        required_fields = [
            "name",
            "species",
            "breed",
            "date_of_birth",
            "gender",
            "weight_kg",
            "photo_url",
            "allergies",
            "adoption_date",
            "current_medication",
            "milestones",
            "notes",
        ]
        collected_fields = state.get("collected_fields", {})

        if state["pet_profile_needed"] and not collected_fields:
            return {
                "response": {
                    "type": "text",
                    "text": "You haven’t created a pet profile yet. Would you like to create one?",
                },
                "collected_fields": collected_fields,
            }

        if (
            state["pet_profile_needed"]
            or "yes" in state["input"].lower()
            or "add another pet" in state["input"].lower()
        ) and not all(field in collected_fields for field in required_fields):
            for field in required_fields:
                if field not in collected_fields:
                    questions = {
                        "name": "What is your pet's name?",
                        "species": "What species is your pet? (e.g., dog, cat)",
                        "breed": "What breed is your pet?",
                        "date_of_birth": "What is your pet's date of birth? (YYYY-MM-DD)",
                        "gender": "What is your pet's gender? (Male/Female)",
                        "weight_kg": "What is your pet's weight in kg?",
                        "photo_url": "Please provide a photo URL for your pet (or 'none')",
                        "allergies": "Does your pet have allergies? (Specify or 'none')",
                        "adoption_date": "When was your pet adopted? (YYYY-MM-DD)",
                        "current_medication": "Is your pet on medication? (Specify or 'none')",
                        "milestones": "Any milestones for your pet? (Specify or 'none')",
                        "notes": "Any additional notes? (Specify or 'none')",
                    }
                    collected_fields[field] = (
                        state["input"] if state["input"].lower() != "none" else ""
                    )
                    return {
                        "response": {
                            "type": "text",
                            "text": questions[field],
                        },
                        "collected_fields": collected_fields,
                    }
            collected_fields["user_id"] = state["user_id"]
            result = create_pet_profile_tool.func(collected_fields)
            if "error" in result:
                return {
                    "response": {"type": "text", "text": result["error"]},
                    "collected_fields": collected_fields,
                }
            journal_entry = pet_journal_tool.func(
                f"Pet profile created for user {state['user_id']}: {collected_fields['name']}"
            )
            journal_query = write_query_tool.func(json.loads(journal_entry))
            execute_query_tool.func(journal_query)
            return {
                "response": {
                    "type": "profile_update",
                    "text": f"Pet profile for {collected_fields['name']} created successfully. How can we assist you?",
                },
                "collected_fields": {},
                "pet_profile_needed": False,  # Reset after creation
            }

        return {
            "response": {
                "type": "text",
                "text": "Would you like to add another pet?",
            },
            "collected_fields": collected_fields,
        }

    return state


def handle_query(state: AgentState) -> AgentState:
    query = state["input"].lower()
    user_id = state["user_id"]
    behavior_keywords = [
        "diet",
        "feed",
        "care",
        "behavior",
        "health",
        "medication",
        "note",
    ]
    generic_keywords = ["hi", "hey", "hello"]

    if any(keyword in query for keyword in generic_keywords):
        return {
            "response": {"type": "text", "text": "Hello! How can we assist you today?"},
            "history": state["history"]
            + [
                HumanMessage(content=query),
                AIMessage(
                    content=json.dumps(
                        {"type": "text", "text": "Hello! How can we assist you today?"}
                    )
                ),
            ],
        }

    if "product" in query or "buy" in query:
        product_query = {
            "query": query,
            "table": "products",
            "fields": ["product_id", "name", "price", "photo_url", "description"],
            "limit": 7,
        }
        if user_id:
            pet_query = f"SELECT pet_id, species, allergies FROM pets WHERE user_id = '{user_id}' AND is_delete = 0 LIMIT 1"
            pet_data = execute_query_tool.func(pet_query)
            if pet_data and isinstance(pet_data, list) and len(pet_data) > 0:
                pet_data_dict = {
                    "pet_id": pet_data[0][0],
                    "species": pet_data[0][1],
                    "allergies": pet_data[0][2] or "none",
                }
                product_query["query"] = (
                    f"products for {pet_data_dict['species']} avoiding {pet_data_dict['allergies']}"
                )
            else:
                product_query["query"] = query
        sql_query = write_query_tool.func(product_query)
        result = execute_query_tool.func(sql_query)
        if not result:
            return {
                "response": {"type": "text", "text": "No matching products found."},
                "history": state["history"],
            }
        products = [
            {
                "product_id": row[0],
                "name": row[1],
                "price": float(row[2]),
                "photo_url": row[3],
                "description": row[4],
            }
            for row in result
        ]
        return {
            "response": {"type": "carousel", "products": products},
            "history": state["history"]
            + [
                HumanMessage(content=query),
                AIMessage(
                    content=json.dumps({"type": "carousel", "products": products})
                ),
            ],
        }

    if "add to cart" in query:
        product_query = write_query_tool.func(
            {"query": query, "table": "products", "fields": ["product_id"], "limit": 1}
        )
        product_result = execute_query_tool.func(product_query)
        if product_result:
            product_id = product_result[0][0]
            upsell_query = write_query_tool.func(
                {
                    "query": "similar products",
                    "table": "products",
                    "fields": [
                        "product_id",
                        "name",
                        "price",
                        "photo_url",
                        "description",
                    ],
                    "limit": 3,
                }
            )
            upsell_result = execute_query_tool.func(upsell_query)
            upsell_products = (
                [
                    {
                        "product_id": row[0],
                        "name": row[1],
                        "price": float(row[2]),
                        "photo_url": row[3],
                        "description": row[4],
                    }
                    for row in upsell_result
                ]
                if upsell_result
                else []
            )
            if not user_id:
                return {
                    "response": {
                        "type": "text",
                        "text": "Please provide your name to add to cart.",
                        "collected_fields": {"product_id": product_id},
                    },
                    "history": state["history"],
                    "collected_fields": {"product_id": product_id},
                }
            return {
                "response": {
                    "type": "review",
                    "product_id": product_id,
                    "upsell": {"type": "carousel", "products": upsell_products},
                    "text": "Do you want to see similar products?",
                },
                "history": state["history"]
                + [
                    HumanMessage(content=query),
                    AIMessage(
                        content=json.dumps(
                            {
                                "type": "review",
                                "product_id": product_id,
                                "upsell": {
                                    "type": "carousel",
                                    "products": upsell_products,
                                },
                                "text": "Do you want to see similar products?",
                            }
                        )
                    ),
                ],
            }
        return {
            "response": {"type": "text", "text": "Product not found to add to cart."},
            "history": state["history"],
        }

    if any(keyword in query for keyword in behavior_keywords):
        journal_entry = pet_journal_tool.func(
            f"Behavior update: {query} for user {user_id}"
        )
        journal_query = write_query_tool.func(json.loads(journal_entry))
        execute_query_tool.func(journal_query)
        prompt = ChatPromptTemplate.from_messages(
            [
                ("system", system_prompt),
                MessagesPlaceholder(variable_name="history"),
                ("user", "{input}"),
            ]
        )
        chain = prompt | llm | output_parser
        response = chain.invoke({"history": state["history"] or [], "input": query})
        return {
            "response": {"type": "text", "text": response},
            "history": state["history"]
            + [
                HumanMessage(content=query),
                AIMessage(content=json.dumps({"type": "text", "text": response})),
            ],
        }

    return {
        "response": {
            "type": "text",
            "text": "We provide general assistance. Please specify your query.",
        },
        "history": state["history"]
        + [
            HumanMessage(content=query),
            AIMessage(
                content=json.dumps(
                    {
                        "type": "text",
                        "text": "We provide general assistance. Please specify your query.",
                    }
                )
            ),
        ],
    }


# Conditional edge logic
def route_query(state: AgentState) -> str:
    print(f"Routing state: {state}")
    query = state["input"].lower()
    if not state["user_id"]:
        return "handle_login"
    if (
        state["pet_profile_needed"]
        or "add another pet" in query
        or "create pet profile" in query
    ):
        return "handle_pet_profile"
    return "handle_query"


# Build the graph
workflow = StateGraph(AgentState)
workflow.add_node("parse_input", parse_input)
workflow.add_node("handle_login", handle_login)
workflow.add_node("handle_pet_profile", handle_pet_profile)
workflow.add_node("handle_query", handle_query)
workflow.set_entry_point("parse_input")
workflow.add_conditional_edges(
    "parse_input",
    route_query,
    {
        "handle_login": "handle_login",
        "handle_pet_profile": "handle_pet_profile",
        "handle_query": "handle_query",
    },
)
workflow.add_edge("handle_login", END)
workflow.add_edge("handle_pet_profile", END)
workflow.add_edge("handle_query", END)

# Compile the graph
app = workflow.compile()
try:
    png_data = app.get_graph().draw_mermaid_png()
    with open("mermaid_graph2.png", "wb") as f:
        f.write(png_data)
    display(Image("mermaid_graph2.png"))
except Exception:
    pass


def create_pet_agent2():
    return app
