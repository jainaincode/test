import logging
import os

# Ensure logs directory exists
LOG_DIR = "static"
os.makedirs(LOG_DIR, exist_ok=True)

# Path to log file
LOG_FILE = os.path.join(LOG_DIR, "app.txt")

# Create logger instance
logger = logging.getLogger("doc_logger")
logger.setLevel(logging.INFO)

# Prevent duplicate handlers on reload
if not logger.handlers:

    # File handler
    file_handler = logging.FileHandler(LOG_FILE)
    file_formatter = logging.Formatter(
        "%(asctime)s - %(levelname)s - %(message)s", "%Y-%m-%d %H:%M:%S"
    )
    file_handler.setFormatter(file_formatter)
    logger.addHandler(file_handler)

    # Console handler
    console_handler = logging.StreamHandler()
    console_formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)
