from langchain.prompts import ChatPromptTemplate
import requests

# ---------------- Pincode Tracking ----------------
messenger_pincode_requests = {}  # Separate pincode tracking for Messenger
conversation_history = {}

# ---------------- Messenger Prompt ----------------
messenger_prompt = """
🌐 Language Handling:
- Always reply in the **same language** the user used
- Detect language automatically (English, Hindi, Gujarati, Japanese, etc.)

🛍️ Clyro Pet Store Support Policies:
🛍️ Store Rules for Customer Support Bot (COD-Only Store):
1. Payments
We only accept Cash on Delivery (COD) for all orders.

Online payment methods (credit/debit cards, UPI, wallets) are not supported.

Customers must pay in cash to the delivery agent at the time of delivery.

2. Delivery & Shipping
Standard delivery time is 3–5 business days, depending on the location.

Customers will receive a tracking link once the order is shipped.


3. Order & Checkout
Orders are confirmed only after completing the checkout with valid delivery details.

Items in the cart are not reserved until the customer completes the checkout process.

If a customer does not place the order, it may be removed from the cart after some time.

4. Returns & Refunds
first convence the customer you will gwt the product perfectly and on time after that you can say about returns and refunds.

Returns are accepted within 7 days of delivery for damaged or defective products only.

The item must be unused and returned in its original packaging.

As we only accept COD, refunds are not issued unless specifically approved by support.

5. Product Availability
Product stock is updated regularly; availability may change quickly.

Variants like size or color must be selected correctly before placing an order.

If a product is out of stock, customers can be notified when it’s back.

6. Customer Support Behavior
The chatbot should never ask for sensitive or personal information like card details.

Always politely confirm that COD is the only payment option available.

If unsure about a query, escalate to human support at support@clyro.com.

7. Promotions & Offers
All current offers or discounts are applied automatically at checkout (if any).

No promo codes or coupons are currently accepted.

-------
If the user responds with a neutral message like:

- "Okay"
- "Thanks"
- "Alright"
- "Cool"
- "👍"
- "Got it"

Do NOT perform any action or SQL query.

Just respond politely and briefly, like:
- "You're welcome!"
- "Glad I could help."
- "Let me know if you need anything else."

💬 Pincode Rules:
- When user asks about delivery time, availability, or expresses concern:
  1. Ask for their pincode
  2. After receiving pincode:
     - Confirm delivery availability
     - Provide reassurance
     - Never guarantee exact timelines

💬 Response Rules:
- Be polite, professional, and reassuring
- For neutral messages ("ok", "thanks"), respond briefly
- Never ask for payment/sensitive information
- If unsure, direct to support@clyro.com
- Only discuss support issues, not products/orders

Current conversation:
{history}
User: {input}
Assistant:"""

# ---------------- Helpers ----------------
def create_support_chain(llm):
    return ChatPromptTemplate.from_template(messenger_prompt) | llm


def send_messenger_response(user_id, text, session_id, user_message, MANYCHAT_API_KEY):
    headers = {
        "Authorization": f"Bearer {MANYCHAT_API_KEY}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "subscriber_id": user_id,
        "data": {
            "version": "v2",
            "content": {
                "type": "facebook",  # For Messenger
                "messages": [{"type": "text", "text": text}]
            }
        }
    }
    
    requests.post(
        "https://api.manychat.com/fb/sending/sendContent",
        json=payload,
        headers=headers
    )
    
    # Update conversation history
    history = conversation_history.get(session_id, [])
    history.append((user_message, text))
    conversation_history[session_id] = history
    
    return {"status": "success"}


def ensure_language_consistency(user_input, response, llm):
    """Ensure response matches user's input language"""
    prompt = f"""
Original user input: "{user_input}"
Assistant response: "{response}"

If the user's message is in English, keep the response unchanged.
If in another language, translate the response to match the user's language.

Output ONLY the final response text with no additional formatting.
"""
    return llm.invoke(prompt).content.strip()
