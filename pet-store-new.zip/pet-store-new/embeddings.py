import requests, os, re
from dotenv import load_dotenv
from langchain_core.documents import Document
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
from langchain_community.document_loaders import WebBaseLoader
from langchain_openai import OpenAIEmbeddings
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_pinecone import PineconeVectorStore
from pinecone import Pinecone as PineconeClient
from langchain_openai import AzureChatOpenAI
from langchain_openai import AzureOpenAIEmbeddings
import time
from requests_html import HTMLSession


load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
PINECONE_API_KEY = os.getenv("PINECONE_API_KEY")
PINECONE_ENVIRONMENT = os.getenv("PINECONE_ENVIRONMENT")
AZURE_ENDPOINT = os.getenv(
    "AZURE_ENDPOINT", "https://your-azure-openai-endpoint.openai.azure.com"
)
openai_embeddings = AzureOpenAIEmbeddings(
    azure_deployment="text-embedding-3-small",  # e.g., "text-embedding-ada-002"
    openai_api_key="9rCqSjTo24z4dLOxqMlv3r94Sn3zCqH6Vo0k38TnFRXSEretLBprJQQJ99BDACHYHv6XJ3w3AAAAACOGFQW5",
    azure_endpoint="https://rushi-m9gm4fle-eastus2.openai.azure.com/",
    openai_api_version="2024-12-01-preview",  # or the latest supported version
)
pinecone_index_name = "testing"
namespace = "pet_smart"

pinecone = PineconeClient(api_key=PINECONE_API_KEY, environment=PINECONE_ENVIRONMENT)
index = pinecone.Index(pinecone_index_name)

llm = AzureChatOpenAI(
    azure_endpoint=AZURE_ENDPOINT,
    azure_deployment="gpt-4o",
    api_version="2024-05-01-preview",
    temperature=0.2,
)

base_url = "https://www.petsmart.com/dog/"
links = [
    "https://www.petsmart.com/dog/clothing-and-shoes",
    "https://www.petsmart.com/dog/grooming-supplies",
    "https://www.petsmart.com/dog/health-and-wellness",
]
session = HTMLSession()

headers = {"User-Agent": "Mozilla/5.0"}
res = requests.get(base_url, headers=headers)
# print(res.text[:1000])  # Show the first 1000 chars of raw HTML


def get_internal_links2(base_url):
    visited = set()
    to_visit = [base_url]
    all_links = set()

    while to_visit:
        url = to_visit.pop()
        if url in visited:
            continue
        visited.add(url)
        print("Crawling:", url)

        try:
            response = session.get(url)
            response.html.render(timeout=20)  # render JS
        except Exception as e:
            print(f"Failed: {e}")
            continue

        for link in response.html.absolute_links:
            if base_url in link and urlparse(link).path != "/":
                all_links.add(link)

    return list(all_links)


def get_internal_links(base_url):
    visited = set()
    to_visit = [base_url]
    all_links = set()

    while to_visit:
        url = to_visit.pop()
        if url in visited:
            continue
        visited.add(url)
        print("Crawling:", url)

        try:
            response = requests.get(url, timeout=5)
            soup = BeautifulSoup(response.text, "html.parser")
        except Exception as e:
            print("Failed:", e)
            continue

        for a_tag in soup.find_all("a", href=True):
            href = a_tag["href"]
            full_url = urljoin(base_url, href)
            parsed = urlparse(full_url)

            # Filter only internal / English links
            if base_url in full_url and "/en/" in full_url:
                cleaned_url = full_url.split("#")[0]  # remove fragment
                if cleaned_url not in visited:
                    to_visit.append(cleaned_url)
                    all_links.add(cleaned_url)

    return list(all_links)


def clean_text_from_url(url):
    try:
        response = requests.get(url, timeout=10)
        if response.status_code != 200:
            return ""
        soup = BeautifulSoup(response.text, "html.parser")

        # Remove unwanted tags
        for tag in soup(["script", "style", "nav", "footer", "header", "noscript"]):
            tag.decompose()

        # Get raw text
        text = soup.get_text(separator="\n")

        # Clean multiple newlines and whitespace
        text = re.sub(r"\n+", "\n", text)
        text = "\n".join([line.strip() for line in text.splitlines() if line.strip()])

        return text
    except Exception as e:
        print(f"Error scraping {url}: {e}")
        return ""


def is_supported_html_page(url):
    # Check based on file extension
    excluded_exts = [
        ".pdf",
        ".jpg",
        ".jpeg",
        ".png",
        ".gif",
        ".doc",
        ".docx",
        ".xls",
        ".xlsx",
    ]
    return not any(url.lower().endswith(ext) for ext in excluded_exts)


def scrape_page(url):
    try:
        if not is_supported_html_page(url):
            print(f"🚫 Skipping unsupported URL: {url}")
            return None

        print(f"🧹 Scraping {url}")
        r = session.get(url)
        r.html.render(timeout=20)

        data = {}
        headings = r.html.find("h1, h2, h3")
        data["headings"] = [h.text for h in headings]

        paragraphs = r.html.find("p")
        data["paragraphs"] = [p.text for p in paragraphs]

        return data

    except Exception as e:
        print(f"❌ Error scraping {url}: {e}")
        return None


def scrape_all_links(link_list):
    data = {}
    for url in link_list:
        result = scrape_page(url)
        if result:
            data[url] = result
        time.sleep(1.5)  # Be kind to servers
    return data


# all_links = get_internal_links(base_url)
# internal_links = get_internal_links2(link)
# print("✅ Found Links:", internal_links)


def collect_all_internal_links(base_links):
    all_links = set()

    for link in base_links:
        try:
            internal_links = get_internal_links2(link)
            print(f"🔗 {len(internal_links)} links found on {link}")
            all_links.update(internal_links)
        except Exception as e:
            print(f"❌ Error scraping {link}: {e}")

    return list(all_links)


all_dog_store_links = collect_all_internal_links(links)

print("✅ Total dog store links collected:", len(all_dog_store_links))


scraped = scrape_all_links(all_dog_store_links)
print("Scraped_data", scraped)

documents = [
    Document(
        page_content="\n".join(text.get("headings", []) + text.get("paragraphs", [])),
        metadata={"source": url},
    )
    for url, text in scraped.items()
]


text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=100)
texts = text_splitter.split_documents(documents)

vectorstore = PineconeVectorStore.from_documents(
    texts,
    embedding=openai_embeddings,
    index_name=pinecone_index_name,
    namespace=namespace,
)
