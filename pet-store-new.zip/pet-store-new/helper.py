import mysql.connector
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import requests
from fastapi.responses import JSONResponse
import os

# ---------- SMTP CONFIG ----------
SMTP_HOST = "smtp.gmail.com"
SMTP_PORT = 587
SMTP_USER = "bloomai.notify@gmail.com"
SMTP_PASSWORD = "ghlk dxrq qqlz odee"

MYSQL_USER = os.getenv("DB_USER")
MYSQL_PASSWORD = os.getenv("DB_PASSWORD")
MYSQL_HOST = os.getenv("DB_HOST")
MYSQL_DB = os.getenv("DB_NAME")


# ---------- DB CONNECTION ----------
def get_db_connection():
    return mysql.connector.connect(
        host=MYSQL_HOST,
        port=3306,
        user=MYSQL_USER,
        password=MYSQL_PASSWORD,
        database=MYSQL_DB,
    )


# ---------- PASSWORD UTILS ----------
def hash_password(password: str) -> str:
    return generate_password_hash(password)


def verify_password(hash_value: str, password: str) -> bool:
    return check_password_hash(hash_value, password)


# ---------- EMAIL SENDER ----------
def send_email(to_email: str, subject: str, html_body: str):
    msg = MIMEMultipart()
    msg["From"] = SMTP_USER
    msg["To"] = to_email
    msg["Subject"] = subject
    msg.attach(MIMEText(html_body, "html"))

    try:
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
            server.set_debuglevel(1)  # print SMTP conversation
            server.starttls()
            server.login(SMTP_USER, SMTP_PASSWORD)
            server.send_message(msg)
            print("✅ Email sent successfully")
    except smtplib.SMTPAuthenticationError as e:
        print("❌ SMTP Authentication failed:", e.smtp_error.decode())
        raise
    except Exception as e:
        print("❌ Other SMTP error:", e)
        raise


# ---------- DB QUERY HELPERS ----------
def fetch_all(query: str, params=None):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute(query, params or ())
    rows = cursor.fetchall()
    cursor.close()
    conn.close()
    return rows


def fetch_one(query: str, params=None):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute(query, params or ())
    row = cursor.fetchone()
    cursor.close()
    conn.close()
    return row


def execute_query(query: str, params=None, commit=False):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(query, params or ())
    if commit:
        conn.commit()
    last_id = cursor.lastrowid
    cursor.close()
    conn.close()
    return last_id


def execute_many(queries_with_params, commit=False):
    conn = get_db_connection()
    cursor = conn.cursor()
    for query, params in queries_with_params:
        cursor.execute(query, params)
    if commit:
        conn.commit()
    cursor.close()
    conn.close()
