from dotenv import load_dotenv
import os, json
from langchain_openai import OpenAIEmbeddings

from langchain_core.output_parsers import StrOutputParser

from langchain_core.prompts import (
    ChatPromptTemplate,
    PromptTemplate,
    MessagesPlaceholder,
)
from langchain.memory import ConversationBufferMemory
from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain_community.chat_message_histories import ChatMessageHistory
from langchain_core.tools import tool, Tool, StructuredTool
from langchain.agents import (
    AgentExecutor,
)
from langchain.tools.retriever import create_retriever_tool

from langchain.agents.format_scratchpad.openai_tools import (
    format_to_openai_tool_messages,
)
from langchain.agents.output_parsers.openai_tools import OpenAIToolsAgentOutputParser
from langchain_core.output_parsers import JsonOutputParser
from pinecone import Pinecone as PineconeClient
from langchain_community.vectorstores import Pinecone
from langchain_openai import AzureChatOpenAI
from langchain_openai import AzureOpenAIEmbeddings
from langchain_community.utilities import SQLDatabase
from langchain_core.output_parsers import StrOutputParser
from langchain import hub
from langchain_community.tools import QuerySQLDatabaseTool
from werkzeug.security import generate_password_hash, check_password_hash

load_dotenv()

PINECONE_API_KEY = os.getenv("PINECONE_API_KEY")
PINECONE_ENVIRONMENT = os.getenv("PINECONE_ENVIRONMENT")
AZURE_ENDPOINT = os.getenv(
    "AZURE_ENDPOINT", "https://pg-mcbw91ko-eastus2.cognitiveservices.azure.com/"
)
AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")
openai_embeddings = AzureOpenAIEmbeddings(
    azure_deployment="text-embedding-3-small",  # e.g., "text-embedding-ada-002"
    openai_api_key="4eqKbBqorxl3A8LYPxqqUzcTc2LYuDrux5hl6wp9Af0187blgTvzJQQJ99BFACYeBjFXJ3w3AAAAACOG4nXD",
    azure_endpoint="https://narola-ai.cognitiveservices.azure.com/",
    openai_api_version="2024-12-01-preview",  # or the latest supported version
)
pinecone_index_name = "testing"
pinecone = PineconeClient(api_key=PINECONE_API_KEY, environment=PINECONE_ENVIRONMENT)
index = pinecone.Index(pinecone_index_name)
output_parser = StrOutputParser()
# llm2 = ChatOpenAI(model="gpt-4o")
llm = AzureChatOpenAI(
    azure_endpoint=AZURE_ENDPOINT,
    api_key=AZURE_OPENAI_API_KEY,
    azure_deployment="gpt-4.1",
    api_version="2025-01-01-preview",
    temperature=0.2,
)
# print("jency llm", llm)

data = []


# print("after retriever")
message_history = ChatMessageHistory(session_id="pet_smart")
memory = ConversationBufferMemory(memory_key="history", return_messages=True)

MYSQL_HOST = os.getenv("DB_HOST")
MYSQL_USER = os.getenv("DB_USER")
MYSQL_PASSWORD = os.getenv("DB_PASSWORD")
MYSQL_DB = os.getenv("DB_NAME")

db_uri = f"mysql+mysqlconnector://{MYSQL_USER}:{MYSQL_PASSWORD}@{MYSQL_HOST}/{MYSQL_DB}"


def create_pet_agent():
    db = SQLDatabase.from_uri(db_uri)

    def write_query(input_data):
        if isinstance(input_data, str):
            try:
                input_data = json.loads(input_data)
            except json.JSONDecodeError:
                pass

        prompt = """
        Given an input dictionary, create a syntactically correct {dialect} query to run. Limit to {top_k} results unless specified.
        Tables: 
        1. products: product_id, name, category, brand, description, price, stock_gty, allergy_tags, nutrition_facts, photo_url, rating, is_active, created_date, modified_date, is_delete
        - For category there are values like Toy, Food, Supplement, Treat, Grooming only.
        - The `nutrition_facts` column is stored as a JSON-like string, e.g.: 
        "Fat": "15%", "Fiber": "4.4%", "Protein": "27%".
        - If filtering by nutritional values (like 'high protein', 'low fat'), use string matching on this field, e.g.:
        nutrition_facts LIKE %"Protein": "27%" or greater.
        - For allergy_tags, possible values include no-chicken, no-allergens, grain-free, no-grain, No Common Allergens .

        2. pets: pet_id, user_id, name, species, breed, date_of_birth, gender, weight_kg, allergies, current_medication, adoption_date, last_journal_update, milestones, notes, created_date, modified_date, is_delete
        3. pet_journals: journal_id, pet_id, entry_date, entry_type, details, created_date, modified_date, is_delete
        4. users: user_id, name, email, phone, password_hash, preferred_channel, loyalty_status, referral_code, created_date, modified_date, is_delete
        5. offers : offer_id, user_id, type, amount, valid_from, valid_to, status, trigger_event.

        For pet profile or user insertion or updation, use respective tables with valid columns. For product recommendations, query products table, selecting name, price, photo_url (limit 10). Only use provided column names. And return same results as fetched from db. 
        Output only the runnable SQL query as a plain string, without Markdown, code blocks, or any extra text or symbols.
        Input: {input}
        """
        query_prompt_template = PromptTemplate.from_template(prompt)
        prompt = query_prompt_template.invoke(
            {
                "dialect": db.dialect,
                "top_k": 10,
                "table_info": db.get_table_info(),
                "input": json.dumps(input_data),
            }
        )
        query = llm.invoke(prompt).content
        # Strip any Markdown or code block markers
        query = query.strip()
        if query.startswith("```sql") or query.startswith("```"):
            query = query.replace("```sql", "").replace("```", "").strip()
        print(f"Generated query: {query}")
        return query

    write_query_tool = Tool(
        name="write_query",
        func=write_query,
        description="Creates executable SQL queries for INSERT, UPDATE, or SELECT operations on tables: products, pets, pet_journals, orders, order_items, users. Use for pet/user profile management or product queries.",
    )

    def execute_query(sql_query):
        execute_query_tool = QuerySQLDatabaseTool(db=SQLDatabase.from_uri(db_uri))
        return execute_query_tool.invoke(sql_query)

    execute_query_tool = Tool(
        name="execute_query",
        func=execute_query,
        description="Executes SQL queries for INSERT, SELECT, and UPDATE operations.",
    )

    def pet_journal(input_data):
        prompt_template = PromptTemplate.from_template(
            """
            Summarize the input into a structured pet journal entry in JSON format:
            {
                "pet_id": "<uuid>",
                "entry_type": "diet|order|chat_advice|care_note|summary",
                "details": "<summary>",
                "entry_date": "<ISO timestamp or blank>"
            }
            input = {input}
            """
        )
        prompt = ChatPromptTemplate.from_messages(
            [("system", prompt_template.format(input=input_data)), ("user", input_data)]
        )
        chain = prompt | llm
        return chain.invoke({"input": input_data})

    pet_journal_tool = Tool(
        name="pet_journal",
        func=pet_journal,
        description="Logs summaries, diet, orders, or care notes to pet_journals table. Creates structured journal entries from input text.",
    )

    def hash_password(plain_text_password):
        return generate_password_hash(plain_text_password)

    hash_password_tool = Tool(
        name="hash_password",
        func=hash_password,
        description="Securely hashes a password for database storage.",
    )

    def create_user(user_data):
        required_fields = [
            "name",
            "email",
            "phone",
            "password_hash",
            "preferred_channel",
            "loyalty_status",
            "referral_code",
        ]
        # Debug input
        # print(f"create_user input: {user_data}")

        missing_fields = [field for field in required_fields if field not in user_data]
        if missing_fields:
            print(f"Missing fields: {missing_fields}")
            return {
                "error": f"Missing required user fields: {', '.join(missing_fields)}"
            }

        if isinstance(user_data, str):
            try:
                user_data = json.loads(user_data)
            except json.JSONDecodeError as e:
                print(f"JSON parse error: {e}")
                return {"error": "Invalid input format, expected valid JSON string"}

        query = write_query(user_data)
        result = execute_query(query)
        print(f"create_user result: {result}")
        return result

    create_user_tool = StructuredTool.from_function(
        name="create_user",
        func=create_user,
        description="Creates a new user in the users table. Requires name, email, phone, password_hash (hashed), preferred_channel, loyalty_status, referral_code. ",
    )

    def create_pet_profile(pet_data):
        required_fields = [
            "user_id",
            "name",
            "species",
            "breed",
            "date_of_birth",
            "gender",
            "weight_kg",
            "allergies",
            "adoption_date",
            "current_medication",
            "milestones",
            "additional_notes",
        ]
        print(f"input: {pet_data}")

        # Handle list input by mapping to dictionary
        if isinstance(pet_data, list):
            if len(pet_data) != len(required_fields):
                return {
                    "error": f"Expected {len(required_fields)} fields, got {len(pet_data)}"
                }
            pet_data = dict(zip(required_fields, pet_data))

        # Existing validation for dictionary or JSON string
        missing_fields = [field for field in required_fields if field not in pet_data]
        if missing_fields:
            print(f"Missing fields: {missing_fields}")
            return {
                "error": f"Missing required user fields: {', '.join(missing_fields)}"
            }

        if isinstance(pet_data, str):
            try:
                pet_data = json.loads(pet_data)
            except json.JSONDecodeError as e:
                print(f"JSON parse error: {e}")
                return {"error": "Invalid input format, expected valid JSON string"}

        query = write_query(pet_data)
        result = execute_query(query)
        print(f"create_pet_profile result: {result}")
        return result

    create_pet_profile_tool = StructuredTool.from_function(
        name="create_pet_profile",
        func=create_pet_profile,
        description="Creates or updates a pet profile. Pass a dictionary containing pet data. If data is incomplete, it will return the next required field. Fields: user_id, name, species, breed, date_of_birth, gender, weight_kg, allergies, adoption_date, current_medication, milestones, additional_notes.",
    )

    def product_recommendation(input_data):
        """Takes filter params (dict/string), writes SQL query & fetches results"""
        query = write_query(input_data)
        execute_query_tool = QuerySQLDatabaseTool(db=SQLDatabase.from_uri(db_uri))
        result = execute_query_tool.invoke(query)
        return result

    product_recommendation_tool = StructuredTool.from_function(
        name="product_recommendation",
        func=product_recommendation,
        description=(
            "Fetches product recommendations from the products table. "
            "Input can be filters like {category: 'dog food', allergy_tags: 'grain-free'}. "
            "Always returns exact DB results (name, price, photo_url)."
        ),
    )

    tools = [
        write_query_tool,
        execute_query_tool,
        pet_journal_tool,
        hash_password_tool,
        create_user_tool,
        create_pet_profile_tool,
        product_recommendation_tool,
    ]
    # print("after retriever")
    llm_with_tools = llm.bind_tools(tools)
    # print("after bind tools", llm_with_tools)
    prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                """
                You are a helpful Pet Store AI assistant. Guide users conversationally to create pet profiles, answer pet queries, and suggest products from the database.

            Input Formats:
            1. Not logged in (when user_id is none/null): "User query | Pet Profile Needed: false | user_id: None/null"
                - Guide user to create an account before pet profile creation but answer general queries and general product recommendations.
               - Answer queries. For pet recommendations, prompt for login or pet profile creation.
               - When user is not logged in still product recommendations should be in type carousel in json.
               - If user agrees to login, collect one field at a time: name, email, phone, preferred_channel(email,sms,whatsapp,other), loyalty_status, referral_code, password
               - call hash_password_tool and pass password in it the result is your hashed password which you will use in create_user tool.
               - Use create_user tool after collecting all fields. Always pass a single dictionary or JSON string containing all required fields: name, email, phone, password_hash, preferred_channel, loyalty_status, referral_code
               - After it's success return in json : "type" text, "text" : <success message>
            2. Logged in: "User query | Pet Profile Needed: true/false | user_id: <ID>"
               - Use user_id for data operations. Detect if pet profile creation is needed.

            Pet Profile Handling:
            - If Pet Profile Needed is True:
            - Ask if user wants to create pet profile Format in json : "type" : text, "text" : <your answer>
              - Collect one field at a time: name, species, breed, date_of_birth, gender, weight_kg, allergies, adoption_date, current_medication, milestones, additional_notes.
              - If user says no or say that he/she doesn't want to provide some fields then keep that field as None and move to next field.
              - Use create_pet_profile tool after collecting all fields. While invoking the tool provide user_id which we got in input if user_id is none then fetch it from users table where email is the one we used fro creating user.
              - When calling the create_pet_profile tool, always pass a single dictionary or JSON string containing all required fields: user_id, name, species, breed, date_of_birth, gender, weight_kg, allergies, adoption_date, current_medication, milestones, additional_notes
              - Respond in json: "type": "profile_update", "text": "Pet profile created successfully. <Any follow-up questions>" 
            - If False, Use SQL tools to retrieve pet data and then guide user and recommend them products according to their pet's profile.
        

            Profile Updates:
            - If the user provides new info about their pet (e.g., allergy, name, weight, medication, notes), detect the field and update it using SQL tools with the correct pet_id.
            - For updates, always:
            1. Fetch pet_id from pets table using user_id or matching pet name.
            2. Update only the specified field.
            3. Confirm in JSON: "type": "profile_update", "text": "<field> updated successfully for <pet_name>."


            Product Assistance:
            -When the user asks a specific product-related question: Ask a clarifying or follow-up question unless the intent is already clear and you understand what user wants and for which pet. Use the product_recommendation_tool to fetch product info, considering pet profile and allergies. 
            - The input in product_recommendation_tool will be filters like category: 'dog food', allergy_tags: 'grain-free' or any other filter which you think is relevant to fetch products.
            - Everytime you are recommending products use type as carousel in json. And give products in carousel format.
            - For product queries return exact same which you get from product_recommendation_tool tool.
            - If you create dummy data you will be penalized.
            - If user asks for product by name or brand, use product_recommendation_tool to fetch exact matches.
            - Don't suggest repetitive products on every user question.
            - **Format in json: "type": "carousel", "products": ["name": "", "price": "", "photo_url": "", ...],"suggestions": [list of 3-4 questions]**
            - If no products found in json: "type": "text", "text": "No matching products found."

            Add to Cart Flow and order placement:
            - Ask if user wants to add more items.
            - If user requests reviews, return in json: "type": "review", "product_id": "<id>"
            - Suggest relevant add-ons or bundles from the products table when the user adds an item to cart or inquires about a product. Make sure to return full names. The items should be recommended by category or what user can buy along with it. Format in json: "type": "carousel", "products": ["name": "", "price": "", "photo_url": "", ...], "suggestions": [list of 3-4 questions]
            - When the user places an order ask for confirmation, and you must:
              Collect name, email, phone from users table, pet_id from pet table in database using sql tool and keep it in memory. This is needed for order placement.
              Collect product_id from products table using sql tool and keep it in memory. 
              Collect delivery_address, quantity, payment method from user and return in json:
              "type": "cart", "text": "You will receive a payment link via email. Your total item cost is: <amount>", "product_id" : <product_id or list of ids>, "name": "<Name of user>", "email": "<Email of user>", "phone": "<phone of user>","delivery_address": "", "quantity" :"", "payment_method" : "","pet_id" : "", "email_text": "Hello\nThis is your cart. Your total payment is...\n<payment link>\nBest regards, Clyro."

            Journal Usage:
            - Silently use pet_journal tool to log diet, orders, care notes or any changes you feel should be noted.
            - Fetch pet_id from pets table using user_id, then insert into pet_journals table.

            Order Handling:
            - Log order summary in pet_journals table using pet_journal tool.
    
            Follow up questions Suggestions:
            - After providing the main answer (except when returning a carousel, review, or cart type), also include 2-4 short, relevant follow-up question suggestions which user should ask from user's point of view in the same JSON object, in a "suggestions" array. The questions should be connected to your response like what should user ask next.
            - Suggestions must be based on the user's current context (pet profile, allergies, product type, or topic).
            - so final response in json will be  "type": "text", "text": "<text>", "suggestions": [list of 3-4 questions]

            - Rules:
            - Return one valid JSON object only. Format in json : "type" : text, text: <your answer>, suggestions:<3-4 recommended questions which user should ask>.
            - Make sure there are **no extra characters, no newlines before or after, and no extra JSON objects**.
            - Make sure the Text answers are well formatted, with bullet points where needed. Also, give bold fonts whereever needed and in important texts and lines and give html use <b> tags and <ul> tags.
            - Be concise, polite, conversational.
            - Use "we provide" instead of "Pet Smart provides".
            - Never mention AI or journal logging unless explicitly asked.
            - Use SQL tools only for profile creation/updates or data retrieval.
            - For concerns (e.g., anxiety, adoption), ask clarifying questions, then suggest products with estimated monthly cost.

                """,
            ),
            MessagesPlaceholder(variable_name="history"),
            ("user", "{input}"),
            MessagesPlaceholder(variable_name="agent_scratchpad"),
        ]
    )
    # print("before agent")
    agent = (
        {
            "input": lambda x: x["input"],
            "agent_scratchpad": lambda x: format_to_openai_tool_messages(
                x["intermediate_steps"]
            ),
            "history": lambda x: x["history"],
        }
        | prompt
        | llm_with_tools
        | OpenAIToolsAgentOutputParser()
    )

    # print("before agent executor")
    agent_executor = AgentExecutor(
        agent=agent,
        tools=tools,
        verbose=True,
        memory=memory,
        max_iterations=10,
        early_stopping=True,
    )
    # print("after")
    agent_with_chat_history = RunnableWithMessageHistory(
        agent_executor,
        lambda session_id: ChatMessageHistory(session_id=session_id),
        input_messages_key="input",
        history_messages_key="history",
    )

    # print("before return")
    return agent_with_chat_history
