from dotenv import load_dotenv
import os
from langchain_openai import OpenAIEmbeddings

from langchain_core.output_parsers import StrOutputParser

from langchain_core.prompts import (
    ChatPromptTemplate,
    PromptTemplate,
    MessagesPlaceholder,
)
from langchain.memory import ConversationBufferMemory
from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain_community.chat_message_histories import ChatMessageHistory
from langchain_core.tools import tool, Tool
from langchain.agents import (
    AgentExecutor,
)
from langchain.tools.retriever import create_retriever_tool

from langchain.agents.format_scratchpad.openai_tools import (
    format_to_openai_tool_messages,
)
from langchain.agents.output_parsers.openai_tools import OpenAIToolsAgentOutputParser
from pinecone import Pinecone as PineconeClient
from langchain_community.vectorstores import Pinecone
from langchain_openai import AzureChatOpenAI
from langchain_openai import AzureOpenAIEmbeddings
from langchain_community.utilities import SQLDatabase
from langchain_core.output_parsers import StrOutputParser
from langchain import hub
from langchain_community.tools import QuerySQLDatabaseTool

load_dotenv()

PINECONE_API_KEY = os.getenv("PINECONE_API_KEY")
PINECONE_ENVIRONMENT = os.getenv("PINECONE_ENVIRONMENT")

AZURE_ENDPOINT = os.getenv(
    "AZURE_ENDPOINT", "https://pg-mcbw91ko-eastus2.cognitiveservices.azure.com/"
)
AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")

openai_embeddings = AzureOpenAIEmbeddings(
    azure_deployment="text-embedding-3-small",  # e.g., "text-embedding-ada-002"
    openai_api_key="4eqKbBqorxl3A8LYPxqqUzcTc2LYuDrux5hl6wp9Af0187blgTvzJQQJ99BFACYeBjFXJ3w3AAAAACOG4nXD",
    azure_endpoint="https://narola-ai.cognitiveservices.azure.com/",
    openai_api_version="2024-12-01-preview",  # or the latest supported version
)
pinecone_index_name = "testing"
pinecone = PineconeClient(api_key=PINECONE_API_KEY, environment=PINECONE_ENVIRONMENT)
index = pinecone.Index(pinecone_index_name)
output_parser = StrOutputParser()
# llm2 = ChatOpenAI(model="gpt-4o")
llm = AzureChatOpenAI(
    azure_endpoint=AZURE_ENDPOINT,
    api_key=AZURE_OPENAI_API_KEY,
    azure_deployment="gpt-4o",
    api_version="2025-01-01-preview",
    temperature=0.2,
)

namespace = "clyro_agent"
data = []


def namespace_exists(index, namespace):
    namespaces = index.describe_index_stats()["namespaces"]
    return namespace in namespaces


if namespace_exists(index, namespace):
    pinecone_vectorstore = Pinecone.from_existing_index(
        embedding=openai_embeddings,
        index_name="testing",
        namespace="clyro_agent",
    )

retriever = pinecone_vectorstore.as_retriever()
# print("after retriever")
message_history = ChatMessageHistory(session_id="clyro_agent")
memory = ConversationBufferMemory(memory_key="history", return_messages=True)


def create_landing_agent():

    retriever_tool = create_retriever_tool(
        retriever,
        "Documents_retrieval",
        "Query a retriever to get information about Clyro agent overview, information etc. Use the information present in retriever only to answer user's question otherwise say I am not sure of that.",
    )
    tools = [retriever_tool]
    # print("after retriever")
    llm_with_tools = llm.bind_tools(tools)
    # print("after bind tools", llm_with_tools)
    prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                """
                You are Clyro, the AI Pet Store Concierge, positioned as a sales specialist inside the admin dashboard.  
                Your role is to sell Clyro to retailers who log in, just as a trained sales representative would.  
                You have access to the “Clyro Sales Training Document” as your knowledge base. When you answer user instead of saying clyro can do this say that I can do this.

                Primary Goals:
                1. Introduce yourself in a friendly, persuasive way get information from retriever tool.

                2. Collect the retailer’s email early.  
                - Politely ask for their email.
                - Validate the email format.  
                - Store it in memory as `retailer_email`.  

                3. Sell the value of Clyro.  
                - Draw benefits from the retriever tool.
                    - 24/7 omnichannel support (web, WhatsApp, Instagram, Facebook, voice).  
                    - Personalized pet care & recommendations.  
                    - Smart upsells, loyalty offers, reorders.  
                    - 25–30 percent repeat revenue growth, 20 percent higher AOV, 30 percent lower support costs.  
                    - Easy integration with Shopify, WooCommerce, Magento, CRMs, and loyalty systems.  

                4. Answer questions like a knowledgeable sales rep.
                - Use retriever tool to respond clearly, persuasively, and factually.  
                - Always add a soft CTA (e.g., “Would you like to see how this could work on your site?”).  

                5. Handle objections confidently.  
                - If user says “Isn’t this just another chatbot?” → Explain Clyro’s differentiators (predictive, proactive, executes actions, not just FAQs).  
                - If worried about integration → reassure with simple API/plugin setup.  
                - If concerned about cost → highlight ROI stats (+3x ROI per conversation).  

                6. Flow of Conversation:  
                - Step 1: Warm introduction → build interest .  
                - Step 2: Ask for email (capture lead).  
                - Step 3: Explain Clyro’s value → highlight pain points solved.  
                - Step 4: Answer FAQs → handle objections → build excitement.  
                - Step 5: Close with next steps → Book demo / share catalog → Go live.  

                7. Always sound engaging, clear, and confident. 
                - Use light emojis sparingly.  
                - Don’t oversell; instead, guide like a trusted consultant.  

                Response Rules:
                - Default response format:
                
                    "type": "text",
                    "text": "<your response here>"
                

                - When capturing a lead (email):
                
                    "type": "text",
                    "text": "<your response here>",
                    "lead": "<captured_email>"

                - Make sure there are **no extra characters, no newlines before or after, and no extra JSON objects**.
                - Make sure the Text answers are well formatted, with bullet points where needed. Also, give bold fonts whereever needed and in important texts and lines and give html use <b> tags and <ul> tags.
                - Be concise, polite, conversational.

                - Never return plain text. Always respond in JSON.  

                Memory Instructions:
                - Save collected email and retailer details.  
                - If user revisits, greet them by name/email and continue where you left off.  

                Remember: You are not just answering questions. You are actively selling Clyro as the must-have AI agent for pet retailers, based on the sales training document.  Be proactive, persuasive, and focused on conversion!

                """,
            ),
            MessagesPlaceholder(variable_name="history"),
            ("user", "{input}"),
            MessagesPlaceholder(variable_name="agent_scratchpad"),
        ]
    )
    # print("before agent")
    agent = (
        {
            "input": lambda x: x["input"],
            "agent_scratchpad": lambda x: format_to_openai_tool_messages(
                x["intermediate_steps"]
            ),
            "history": lambda x: x["history"],
        }
        | prompt
        | llm_with_tools
        | OpenAIToolsAgentOutputParser()
    )
    # print("before agent executor")
    agent_executor = AgentExecutor(
        agent=agent, tools=tools, verbose=True, memory=memory, max_iterations=5
    )
    # print("after")
    agent_with_chat_history = RunnableWithMessageHistory(
        agent_executor,
        lambda session_id: message_history,
        input_messages_key="input",
        history_messages_key="history",
    )
    # print("before return")
    return agent_with_chat_history
