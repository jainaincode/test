import os
from fastapi import FastAPI
from main2 import app
import uvicorn

application = app

if __name__ == "__main__":
    uvicorn.run("main2:app", host="0.0.0.0")
