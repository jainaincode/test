from dotenv import load_dotenv
import os
from langchain_core.output_parsers import StrOutputParser

from langchain_core.prompts import (
    ChatPromptTemplate,
    PromptTemplate,
    MessagesPlaceholder,
)
from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain_community.chat_message_histories import ChatMessageHistory
from langchain_core.tools import tool, Tool, StructuredTool
from langchain.agents import (
    AgentExecutor,
)
from langchain.agents.format_scratchpad.openai_tools import (
    format_to_openai_tool_messages,
)
from langchain.agents.output_parsers.openai_tools import OpenAIToolsAgentOutputParser
from langchain.chains import LLMChain
from langchain_openai import AzureChatOpenAI

load_dotenv()

AZURE_ENDPOINT = os.getenv(
    "AZURE_ENDPOINT", "https://pg-mcbw91ko-eastus2.cognitiveservices.azure.com/"
)
AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")

llm = AzureChatOpenAI(
    azure_endpoint=AZURE_ENDPOINT,
    api_key=AZURE_OPENAI_API_KEY,
    azure_deployment="gpt-4.1",
    api_version="2025-01-01-preview",
    temperature=0.2,
)


# -------- Tool function --------
def summarize_conversation(chat_text: str) -> str:

    prompt = f"""Summarize this chatbot conversation:\n\n{chat_text}.You will analyze the full conversation between the user and the bot.
    
    Instructions:
    - If the bot recommended a specific diet plan in the conversation, include the details under "diet_plan_recommendation". Otherwise, leave it as an empty string "".
    - If the user asked the bot to set reminders, or if reminders were discussed, extract them into "reminders". Otherwise, "".
    - If the bot created or suggested any exercise/mental health plan, include it in "exercise_and_mental_plan". Otherwise, "".
    - "general_summary" should contain a concise summary of the overall conversation in 2–3 sentences.  
    - Always return valid JSON only. Do not include extra text or explanations outside JSON.
    """
    return llm.invoke(prompt).content


create_summary_tool = StructuredTool.from_function(
    name="summarize_conversation",
    func=summarize_conversation,
    description="Creates a brief summary of the conversation between the user and the AI assistant.",
)
tools = [create_summary_tool]
llm_with_tools = llm.bind_tools(tools)

# -------- Prompt --------
prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            """You are a helpful assistant that summarizes conversations between users and a pet store AI assistant.

            - Return the result strictly as a JSON array of objects.  
                Each object must have two fields:
                1. "summary_text": A short, clear summary of the item which you will get from tool.
                2. "summary_type": One of ["diet_plan_recommendation", "reminder", "exercise_and_mental_plan", "general_summary"].

                If a category is not mentioned in the conversation, still include it with summary_text set to "" (an empty string).
                Output format example:
                [
                in json brackets
                    "summary_text": "Bella needs a chicken-free diet. Suggested lamb, salmon, or turkey food options.",
                    "summary_type": "diet_plan_recommendation"
                ,
                in json brackets
                    "summary_text": "User asked to remind feeding Bella at 9am and 6pm.",
                    "summary_type": "reminder"
                ]
            """,
        ),
        ("user", "{input}"),
        MessagesPlaceholder(variable_name="agent_scratchpad"),
    ]
)

# -------- Agent --------
agent = (
    {
        "input": lambda x: x["input"],
        "agent_scratchpad": lambda x: format_to_openai_tool_messages(
            x["intermediate_steps"]
        ),
    }
    | prompt
    | llm_with_tools
    | OpenAIToolsAgentOutputParser()
)

agent_executor = AgentExecutor(
    agent=agent,
    tools=tools,
    verbose=True,
    max_iterations=10,
    early_stopping=True,
)


# -------- Wrapper function --------
def create_summary(conversations):
    chat_text = "\n".join([f"User: {u}\nBot: {b}" for u, b in conversations])
    result = agent_executor.invoke({"input": chat_text})
    return result["output"]
