from flask import Flask, render_template, request, session, jsonify, Response
from dotenv import load_dotenv
import os, json
from flask_cors import CORS
import mysql.connector
from pet_agent import create_pet_agent

load_dotenv()

app = Flask(__name__)
CORS(app)
app.secret_key = "SECRET-KEY"
app.config["SESSION_PERMANENT"] = True
app.config["SESSION_TYPE"] = "filesystem"
app.config["SESSION_COOKIE_SECURE"] = (
    True  # Set to True in production for secure cookies
)
MYSQL_USER = os.getenv("DB_USER")
MYSQL_PASSWORD = os.getenv("DB_PASSWORD")
MYSQL_HOST = os.getenv("DB_HOST")
MYSQL_DB = os.getenv("DB_NAME")

mysql_config = {
    "user": MYSQL_USER,
    "password": MYSQL_PASSWORD,
    "host": MYSQL_HOST,
    "database": MYSQL_DB,
}

conn = mysql.connector.connect(**mysql_config)
cursor = conn.cursor(dictionary=True)


@app.route("/", methods=["POST", "GET"])
def home():
    return render_template("index.html")


@app.route("/api/login", methods=["POST"])
def api_login():
    data = request.get_json()
    username = data.get("userId")
    password = data.get("password")

    conn = mysql.connector.connect(**mysql_config)
    cursor = conn.cursor(dictionary=True)

    cursor.execute(
        "SELECT id, username FROM pet_store_users WHERE username=%s AND password=%s",
        (username, password),
    )
    user = cursor.fetchone()

    if user:
        session["user_id"] = user["id"]
        # print("Jency session usid", user["id"])
        return jsonify({"success": True})
    else:
        return jsonify({"success": False, "message": "Invalid credentials"}), 401


def is_pet_profile_complete(user_id):
    conn = mysql.connector.connect(**mysql_config)
    cursor = conn.cursor(dictionary=True)

    cursor.execute(
        """
        SELECT name, species, breed, age, weight, allergies, current_medication, last_vet_visit, milestones, additional_notes
        FROM pet_profiles
        WHERE user_id = %s
        """,
        (user_id,),
    )
    profiles = cursor.fetchall()
    cursor.close()
    conn.close()

    if not profiles:
        return False

    # Check if any profile has all required fields filled (you can adjust the logic)
    for profile in profiles:
        if all(
            profile.get(field)
            for field in ["name", "species", "breed", "age", "weight"]
        ):
            return True

    return False


@app.route("/api/pet-profile-status", methods=["GET"])
def api_pet_profile_status():
    user_id = session.get("user_id")
    if not user_id:
        return jsonify({"profile_complete": False}), 401

    profile_complete = is_pet_profile_complete(user_id)
    return jsonify({"profile_complete": profile_complete})


@app.route("/api/pet-profiles", methods=["GET"])
def api_pet_profiles():
    user_id = session.get("user_id")
    if not user_id:
        return jsonify([]), 401

    conn = mysql.connector.connect(**mysql_config)
    cursor = conn.cursor(dictionary=True)
    cursor.execute(
        """
        SELECT name, species, breed, age, weight, allergies, current_medication, last_vet_visit, additional_notes
        FROM pet_profiles
        WHERE user_id = %s
        """,
        (user_id,),
    )
    profiles = cursor.fetchall()
    cursor.close()
    conn.close()

    return jsonify(profiles)


@app.route("/chatbot", methods=["GET", "POST"])
def chatbot():
    if "user_id" not in session:
        return render_template("index.html", error="Please log in first.")

    session["chatbot_name"] = "Pet_store"
    user_id = session["user_id"]

    profile_complete = is_pet_profile_complete(user_id)
    session["pet_profile_complete"] = profile_complete
    # print("jency", profile_complete)
    return render_template("chatbot.html", profile_complete=profile_complete)


@app.route("/get_response", methods=["POST"])
def get_response():
    user_query = request.json.get("user_query")
    user_id = session.get("user_id")
    if not user_id:
        return jsonify({"error": "Unauthorized"}), 401
    pet_profile_complete = session.get("pet_profile_complete", False)
    # Process the query
    if user_query:
        try:
            pet_agent = create_pet_agent()
            combined_input = f"{user_query} | Pet Profile Needed: {pet_profile_complete} | user_id : {user_id}"
            response = pet_agent.invoke(
                {"input": combined_input},
                config={"configurable": {"session_id": "chatbot_name"}},
            )
            output_json = json.loads(response["output"])
            print("jency output", output_json)
            if output_json.get("type") == "text":
                final_message = output_json.get("text")
                return Response(final_message, mimetype="text/plain")
            else:
                return jsonify(output_json)
        except Exception as e:

            response = f"Error during generation: {e}"
            # print(response)
            return response

    return jsonify("No valid JSON response found."), 200


@app.route("/process-query-make", methods=["POST", "GET"])
def process_make_query():
    if request.method == "POST":
        # Receive query from Make.com
        data = request.json
        if "query" in data:
            user_query = data.get("query", "")
        else:
            user_query = data.get("img_desc", "")

        # Process the query
        pet_agent = create_pet_agent()
        response = pet_agent.invoke(
            {"input": user_query},
            config={"configurable": {"session_id": "chatbot_name"}},
        )
        response_text = response["output"]
        # print("Response before try", response_text)
        json_start = response_text.find("{")
        json_end = response_text.rfind("}")
        if json_start != -1 and json_end != -1:
            json_str = response_text[json_start : json_end + 1]
            try:
                # print("hi in try")
                parsed_response = json.loads(json_str)
                # print("hi", parsed_response)
                return jsonify(parsed_response), 200
            except json.JSONDecodeError:
                return jsonify("Error parsing JSON response.")
        return jsonify("No valid JSON response found."), 200
    return jsonify({"response": "Hi, in GET"}), 200


if __name__ == "__main__":
    app.run(host="0.0.0.0", debug=True, port=8000)
