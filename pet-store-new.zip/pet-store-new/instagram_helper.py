from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
import requests, os

# Shared memory for sessions
conversation_history = {}
pincode_requests = {}


def get_user_profile_by_ig(ig_username: str, db_uri: str):
    try:
        ssl_args = {
                "ssl": {
                    "fake_flag_to_enable_tls": True
                }
            }

        engine = create_engine(db_uri, connect_args=ssl_args)
        Session = sessionmaker(bind=engine)
        session = Session()

        # Fetch user by IG username
        query = text("SELECT * FROM users WHERE ig_username = :ig_username")
        result = session.execute(query, {"ig_username": ig_username}).fetchall()

        if not result:
            return None

        user = result[0]
        user_id = user[0]
        name = user[1]
        email = user[2]
        phone = user[3]  # optional if needed

        cart_query = text("""
            SELECT p.name AS product_name, oi.quantity
            FROM order_items oi
            JOIN orders o ON oi.order_id = o.order_id
            JOIN products p ON oi.product_id = p.product_id
            WHERE o.user_id = :user_id AND o.status = 'pending'
        """)
        cart_items = session.execute(cart_query, {"user_id": user_id}).fetchall()

        order_query = text("""
            SELECT * FROM orders
            WHERE user_id = :user_id AND status = 'completed'
            ORDER BY order_date DESC
            LIMIT 3
        """)
        orders = session.execute(order_query, {"user_id": user_id}).fetchall()

        return {
            "user": {
                "id": user_id,
                "name": name,
                "email": email,
                "phone": phone,
                "ig_username": ig_username
            },
            "cart_items": [dict(row._mapping) for row in cart_items],
            "orders": [dict(row._mapping) for row in orders]
        }

    except Exception:
        return None


def send_to_manychat(user_id: str, reply_text: str, MANYCHAT_API_KEY: str):
    """Helper to send reply back to ManyChat API"""
    headers = {
        "Authorization": f"Bearer {MANYCHAT_API_KEY}",
        "Content-Type": "application/json",
    }
    mc_payload = {
        "subscriber_id": user_id,
        "data": {
            "version": "v2",
            "content": {
                "type": "instagram",
                "messages": [{"type": "text", "text": reply_text}]
            }
        }
    }
    r = requests.post(
        "https://api.manychat.com/fb/sending/sendContent",
        json=mc_payload,
        headers=headers
    )
    return r.status_code, r.text
